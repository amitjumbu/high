export class Global {
    // For localhost
       public static BASE_USER_ENDPOINT = 'https://localhost:44350/api/';

       // For Live Server
   // public static BASE_USER_ENDPOINT = '';
  }
  
  