﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Models.Entities;
using System;
using System.Collections.Generic;
using System.Text;
using Moq;
using Repository;
using WebAppCore.Controllers;
using Microsoft.AspNetCore.Mvc;

namespace WebAppUnitTest
{
    [TestClass]
    public class ProductControllerTest
    {

        //A:Arrangement
        Product p1;
        Product p2;
        Product p3;

        Category c1;
        Category c2;

        List<Product> productList;
        List<Category> categoryList;

        Mock<IUnitOfWork> uow;
        ProductController ctrl;
        public ProductControllerTest()
        {
            p1 = new Product { ProductId = 1, Name = "MVC Book", UnitPrice = 120M, CategoryId = 1 };
            p2 = new Product { ProductId = 2, Name = "Azue Book", UnitPrice = 320M, CategoryId = 1 };
            p3 = new Product { ProductId = 3, Name = "Node Book", UnitPrice = 220M, CategoryId = 1 };

            c1 = new Category { CategoryId = 1, Name = "Books" };
            c2 = new Category { CategoryId = 2, Name = "Books" };

            productList = new List<Product>();
            productList.Add(p1);
            productList.Add(p2);

            categoryList = new List<Category>();
            categoryList.Add(c1);
            categoryList.Add(c2);

            uow = new Mock<IUnitOfWork>();
            ctrl = new ProductController(uow.Object);
        }

        [TestMethod]
        public void TestIndex()
        {
            //setup
            uow.Setup(u => u.ProductRepo.usp_GetProducts()).Returns(productList);

            //Action
            var result = ctrl.Index() as ViewResult;
            var model = result.Model as List<Product>;

            //Assert
            CollectionAssert.Contains(model, p1);
            CollectionAssert.Contains(model, p2);

            CollectionAssert.DoesNotContain(model, p3);
        }

        [TestMethod]
        public void TestCreatePost()
        {
            //setup
            uow.Setup(u => u.ProductRepo.Add(p3)).Callback((Product prd) =>
            {
                productList.Add(prd);
            });

            //Action
            ctrl.Create(p3);

            //Assert
            CollectionAssert.Contains(productList, p3);
        }

        [TestMethod]
        public void TestEditGet()
        {
            int id = 1;
            //setup
            uow.Setup(u => u.ProductRepo.GetById(id)).Returns((object pid) =>
            {
                return productList.Find(p=>p.ProductId==(int)pid);
            });
            uow.Setup(u => u.CategoryRepo.GetAll()).Returns(categoryList);

            //Action
            var result = ctrl.Edit(id) as ViewResult;
            var model = result.Model as Product;

            //Assert            
            Assert.AreEqual(p1, model);
        }

    }
}
