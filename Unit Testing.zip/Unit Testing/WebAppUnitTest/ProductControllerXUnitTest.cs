﻿using Microsoft.AspNetCore.Mvc;
using Models.Entities;
using Moq;
using Repository;
using System;
using System.Collections.Generic;
using System.Text;
using WebAppCore.Controllers;
using Xunit;

namespace WebAppUnitTest
{
    public class ProductControllerXUnitTest
    {
        //A:Arrangement
        Product p1;
        Product p2;
        Product p3;

        Category c1;
        Category c2;

        List<Product> productList;
        List<Category> categoryList;

        Mock<IUnitOfWork> uow;
        ProductController ctrl;
        public ProductControllerXUnitTest()
        {
            p1 = new Product { ProductId = 1, Name = "MVC Book", UnitPrice = 120M, CategoryId = 1 };
            p2 = new Product { ProductId = 2, Name = "Azue Book", UnitPrice = 320M, CategoryId = 1 };
            p3 = new Product { ProductId = 3, Name = "Node Book", UnitPrice = 220M, CategoryId = 1 };

            c1 = new Category { CategoryId = 1, Name = "Books" };
            c2 = new Category { CategoryId = 2, Name = "Books" };

            productList = new List<Product>();
            productList.Add(p1);
            productList.Add(p2);

            categoryList = new List<Category>();
            categoryList.Add(c1);
            categoryList.Add(c2);

            uow = new Mock<IUnitOfWork>();
            ctrl = new ProductController(uow.Object);
        }

        [Fact]
        public void TestIndex()
        {
            //setup
            uow.Setup(u => u.ProductRepo.usp_GetProducts()).Returns(productList);

            //Action
            var result = ctrl.Index() as ViewResult;
            var model = result.Model as List<Product>;

            //Assert
            Assert.Contains(p1, model);
            Assert.Contains(p2, model);

            Assert.DoesNotContain(p3, model);
        }
    }
}
