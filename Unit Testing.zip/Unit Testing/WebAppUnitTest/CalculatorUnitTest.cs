using Microsoft.VisualStudio.TestTools.UnitTesting;
using Repository;

namespace WebAppUnitTest
{

    [TestClass]
    public class CalculatorUnitTest
    {
        //A:Arrangement
        Calculator calc;
        public CalculatorUnitTest()
        {
            calc = new Calculator();
        }

        [TestMethod]
        public void TestAdd()
        {
            int num1 = 2, num2 = 4;

            //A:Action
            int result = calc.Add(num1, num2);

            //A:Verify
            Assert.AreEqual(num1 + num2, result);
        }
    }
}
