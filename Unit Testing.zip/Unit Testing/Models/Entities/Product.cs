﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models.Entities
{
    [Table("Products")]
   public class Product
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int ProductId { get; set; }

        [Column(TypeName = "varchar(200)")]
        [Required]
        public string Name { get; set; }
        public decimal UnitPrice { get; set; }

        //[ForeignKey("CategoryName")]
        public int CategoryId { get; set; }

        [NotMapped]
        public string Cat_Name { get; set; }

        [ForeignKey("CategoryId")]
        public virtual Category CategoryName { get; set; }
    }
}
