﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models.Entities
{
    public class Category
    {
        public int CategoryId { get; set; }
        public string Name { get; set; }

        [Column(TypeName ="varchar(200)")]
        public string Description { get; set; }
    }
}
