﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Models.Entities;

namespace DAL
{
    public class DatabaseContext : DbContext
    {
        public DatabaseContext()
        {

        }

        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }

        public Product fn_GetProduct(int ProductId)
        {
            return this.Products.FromSql<Product>("Select * from fn_GetProduct(@ProductId)", new SqlParameter("ProductId", ProductId)).FirstOrDefault();
        }

        public List<Product> usp_GetProducts()
        {
            List<Product> productList = new List<Product>();
            using(var command = this.Database.GetDbConnection().CreateCommand())
            {
                command.CommandText = "usp_GetProducts";
                command.CommandType = System.Data.CommandType.StoredProcedure;
                //var parameter = new SqlParameter("ProductId", 1);
                //command.Parameters.Add(parameter);
                this.Database.OpenConnection();
                using(var reader= command.ExecuteReader())
                {                    
                    while(reader.Read()){
                        Product prd = new Product();
                        prd.ProductId = Convert.ToInt32(reader["ProductId"]);
                        prd.Name = Convert.ToString(reader["Name"]);
                        prd.UnitPrice = Convert.ToDecimal(reader["UnitPrice"]);
                        prd.Cat_Name = Convert.ToString(reader["CategoryName"]);

                        productList.Add(prd);
                    }
                }
            }
            return productList;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(@"data source=Shailendra\SqlExpress; initial catalog=EFCore9AM;persist security info=True;user id=sa;password=dotnettricks;");
            }
        }
    }
}
