﻿Create procedure usp_GetProducts
As
begin 
	Select prd.ProductId, prd.Name,prd.UnitPrice, CategoryName=(Select Name from Categories where Categories.CategoryId=prd.CategoryId) from Products as prd
end

GO

Create function fn_GetProduct(@ProductId int)
returns Table
As
return Select * from Products as prd 
where prd.ProductId=@ProductId
