﻿using Models.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Repository.Abstraction
{
    public interface IProductRepository : IRepository<Product>
    {
        IEnumerable<Product> usp_GetProducts();
    }
}
