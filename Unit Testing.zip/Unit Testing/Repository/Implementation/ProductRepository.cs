﻿using DAL;
using Models.Entities;
using Repository.Abstraction;
using System;
using System.Collections.Generic;
using System.Text;

namespace Repository.Implementation
{
    public class ProductRepository : Repository<Product>, IProductRepository
    {
        DatabaseContext context
        {
            get
            {
                return db as DatabaseContext;
            }
        }
        public ProductRepository(DatabaseContext db) : base(db)
        {

        }

        public IEnumerable<Product> usp_GetProducts()
        {
            return context.usp_GetProducts();
        }
    }
}
