﻿using Models.Entities;
using Repository.Abstraction;
using System;
using System.Collections.Generic;
using System.Text;

namespace Repository
{
    public interface IUnitOfWork
    {
        IRepository<Category> CategoryRepo { get; }
        IProductRepository ProductRepo { get; }
        int SaveChanges();
    }
}
