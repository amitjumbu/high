﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Repository
{
    public class Calculator
    {
        public int Add(int x, int y)
        {
            //TO DO:
            int result = x + y;
            return result;
        }
    }
}
