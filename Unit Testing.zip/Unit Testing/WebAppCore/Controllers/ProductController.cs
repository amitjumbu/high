﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DAL;
using Microsoft.AspNetCore.Mvc;
using Models.Entities;
using Repository;
using WebAppCore.Models;

namespace WebAppCore.Controllers
{
    public class ProductController : Controller
    {
        IUnitOfWork uow;
        public ProductController(IUnitOfWork _uow)
        {
            //uow = new UnitOfWork();
            uow = _uow;
        }
        public IActionResult Index()
        {
            var data = uow.ProductRepo.usp_GetProducts();
            return View(data);
        }

        public IActionResult Create()
        {
            ViewBag.CategoryList = uow.CategoryRepo.GetAll().ToList();
            return View();
        }

        [HttpPost]
        public IActionResult Create(Product model)
        {
            ModelState.Remove("ProductId");

            if (ModelState.IsValid)
            {
                uow.ProductRepo.Add(model);
                //  uow.CategoryRepo.Add(model);
                uow.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CategoryList = uow.CategoryRepo.GetAll();
            return View();
        }

        public IActionResult Edit(int id)
        {
            ViewBag.CategoryList = uow.CategoryRepo.GetAll();
            Product model = uow.ProductRepo.GetById(id);
            return View("Create", model);
        }

        [HttpPost]
        public IActionResult Edit(Product model)
        {
            if (ModelState.IsValid)
            {
                uow.ProductRepo.Update(model);
                uow.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.CategoryList = uow.CategoryRepo.GetAll();
            return View("Create", model);
        }

        public IActionResult Delete(int id)
        {
            uow.ProductRepo.DeleteById(id);
            uow.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}