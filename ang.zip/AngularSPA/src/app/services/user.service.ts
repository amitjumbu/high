import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { User } from '../models/user';
import { Observable } from 'rxjs/Rx';

@Injectable()
export class UserService {
  headers: Headers;
  apiAddress: string = 'http://localhost:57380/api'
  constructor(private http: Http) {
    this.headers = new Headers({ 'content-type': 'application/json' });
  }

  GetUsers(): Observable<User[]> {
    return this.http.get(this.apiAddress + '/user').map((res) => {
      return res.json();
    }).catch((err) => Observable.throw(err));
  }

  GetUser(id: number): Observable<User> {
    return this.http.get(this.apiAddress + '/user/' + id).map((res) => {
      return res.json();
    }).catch((err) => Observable.throw(err));
  }

  AddUser(user: User): Observable<Response> {
    return this.http.post(this.apiAddress + '/user/', JSON.stringify(user), { headers: this.headers }).catch((err) => Observable.throw(err));
  }

  UpdateUser(user: User): Observable<Response> {
    return this.http.put(this.apiAddress + '/user/' + user.UserId, JSON.stringify(user), { headers: this.headers }).catch((err) => Observable.throw(err));
  }

  DeleteUser(id: number): Observable<Response> {
    return this.http.delete(this.apiAddress + '/user/' + id).catch((err) => Observable.throw(err));
  }
}
