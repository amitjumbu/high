import { Component, OnInit } from '@angular/core';
import { UserService } from '../services/user.service';
import { User } from '../models/user';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styles: []
})
export class UsersComponent implements OnInit {
  data: User[];
  constructor(private user: UserService) {

  }

  ngOnInit() {
    this.user.GetUsers().subscribe((res) => {
      this.data = res;
    });
  }

  deleteUser(id: number) {
    if (confirm('Are you sure to delete?')) {
      this.user.DeleteUser(id).subscribe((res) => {
        if (res.status == 200) {
          for (var i = 0; i < this.data.length; i++) {
            if (id == this.data[i].UserId) {
              this.data.splice(i, 1);
              break;
            }
          }
        }
      });
    }
  }
}
