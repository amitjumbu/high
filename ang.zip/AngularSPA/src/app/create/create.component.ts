import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { NgForm } from '@angular/forms';
import { UserService } from '../services/user.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styles: []
})
export class CreateComponent implements OnInit {
  user: User;
  id: number;
  constructor(private userService: UserService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
    this.user = new User();
    this.route.params.subscribe((params) => {
      this.id = params.id;
      if (this.id != undefined) {
        this.userService.GetUser(this.id).subscribe((res) => {
          this.user = res;
        });
      }
    });
  }

  saveData(form: NgForm) {
    if (form.valid) {
      if (this.user.UserId != undefined) {
        this.userService.UpdateUser(this.user).subscribe((res) => {
          if (res.status == 200) {
            return this.router.navigate(['/']);
          }
        });
      }
      else {
        this.userService.AddUser(this.user).subscribe((res) => {
          if (res.status == 201) {
            return this.router.navigate(['/']);
          }
        });
      }
    }
  }
}
