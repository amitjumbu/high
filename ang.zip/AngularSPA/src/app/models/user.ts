export class User {
  UserId: number;
  Name: string;
  Address: string;
  Contact: string;
}
