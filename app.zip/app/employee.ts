export class Employee {  
  EmployeeId: string;  
    EmpName: string;  
    DateOfBirth: Date;  
    EmailId: string;  
    Gender: string;  
    Address: string;  
    PinCode: string;  
}  
