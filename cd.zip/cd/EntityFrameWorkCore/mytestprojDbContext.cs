﻿using Microsoft.EntityFrameworkCore;
using Abp.Zero.EntityFrameworkCore;
using mytestproj.Authorization.Roles;
using mytestproj.Authorization.Users;
using mytestproj.MultiTenancy;
using System.Threading.Tasks;
using SimpleTaskSystem.People;
using System.Collections.Generic;
using mytestproj.Models;

namespace mytestproj.EntityFrameworkCore
{
    public class mytestprojDbContext : AbpZeroDbContext<Tenant, Role, User, mytestprojDbContext>
    {
        /* Define a DbSet for each entity of the application */
        public DbSet<Book> Books { get; set; }

        public DbSet<Author> Authors { get; set; }
        public DbSet<Category> Categories { get; set; }
        public mytestprojDbContext(DbContextOptions<mytestprojDbContext> options)
            : base(options)
        {
        }
    }
}
