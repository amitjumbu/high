﻿using Abp.Domain.Services;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace mytestproj.Models
{
    public interface IAuthorManager:IDomainService
    {
        IEnumerable<Author> GetAllList();
        Author GetAuthorByID(int id);
        Task<Author> Create(Author entity);
        void Update(Author entity);
        void Delete(int id);
    }
}
