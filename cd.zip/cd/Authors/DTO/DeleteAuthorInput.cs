﻿using System;
using System.Collections.Generic;
using System.Text;

namespace mytestproj.Authors.DTO
{
    public class DeleteAuthorInput
    {
        public int Id { get; set; }
    }
}
