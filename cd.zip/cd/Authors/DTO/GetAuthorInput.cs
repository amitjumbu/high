﻿using System;
using System.Collections.Generic;
using System.Text;

namespace mytestproj.Authors.DTO
{
    public class GetAuthorInput
    {
        public int Id { get; set; }
    }
}
