﻿using System;
using System.Collections.Generic;
using System.Text;

namespace mytestproj.Authors.DTO
{
    public class CreateAuthorInput
    {
        public string DisplayName { get; set; }
        public string CreationTime { get; set; }
        public DateTime BirthDate { get; set; }
        public DateTime? DeathDate { get; set; }

    }
}
