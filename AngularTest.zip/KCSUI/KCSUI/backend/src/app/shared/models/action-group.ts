export interface ActionGroupTab {
  label: string;
  actionGroups: ActionItem[][];
  hidden?: boolean;
}

export interface ActionItem {
  label: string;
  type: ActionType; // add/edit/delete
  iconClass?: string; // fa fa-home or custom-class
  colorClass?: string; // btn-primary or custom-class
  active?: boolean;
  hidden?: boolean;
  disabled?: boolean;
  menu?: ActionItem[];
}

export type ActionType =
  'add' |
  'edit' |
  'delete' |
  'issue' |
  'profile' |
  'export' |
  'active' |
  'accept' |
  'unlock' |
  'inactive' |
  'resetPassword' |
  'approve' |
  'userName' |
  'changePassword' |
  'logout' |
  'declined' |
  'notification' |
  'alerts' |
  'setupWizard' |
  'language' |
  'english' |
  'hindi' |
  'showDetails' |
  'invoice' |
  'refresh' | 'edittype' |
  'filter' |
  'addnewtype' |
  'view' |
  'import' |
  'reasonCode' | 'addNew' | 'addRow' | 'deleteSelectedRow' |
  'import' | 'flex' | 'publish' | 'lock' |
  'graph'| 'cancel' | 'document' | 
  'copy' | 'homeCancel' | 'save' | 'feedback' | 'share' |
  'associate' | 'void' | 'back';
