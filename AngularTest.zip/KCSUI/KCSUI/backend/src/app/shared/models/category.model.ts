export class CategoryModel {
  IsSelected: boolean;
  Id?: number;
  MembershipName?: string; 
  CategoryType?: string;
  Description?: string;
}
