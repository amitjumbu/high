import { Injectable } from '@angular/core';

// Menu
export interface Menu {
  path?: string;
  title?: string;
  icon?: string;
  type?: string;
  active?: boolean;
  children?: Menu[];
}

@Injectable({
  providedIn: 'root'
})
export class NavService {

  collapseSidebar: boolean = false;
  constructor() { }

  MENUITEMS: Menu[] = [
    { path: '/dashboard/default', title: 'Dashboard', icon: 'home', type: 'link', active: true },

    {
      title: 'Users', icon: 'user-plus', type: 'sub', active: false, children: [
        { path: '/users/list-user', title: 'User List', type: 'link' },
        { path: '/users/create-user', title: 'Create User', type: 'link' }
      ]
    },
    {
      title: 'Settings',
      icon: 'settings',
      type: 'sub',
      active: false,
      children: [
        {
          path: '/settings/profile',
          title: 'Profile',
          type: 'link'
        }
      ]
    },
    {
      title: 'Membership',
      icon: 'user-plus',
      type: 'sub',
      active: false,
      children: [
        {
          path: '/membership/category',
          title: 'Category',
          type: 'link',
          //children: [
          //  { path: '/membership/category/list-category', title: 'list Category', type: 'link' },
          //  { path: '/membership/category/add-category', title: 'add Category', type: 'link' },
          //  { path: '/membership/category/edit-category', title: 'edit Category', type: 'link' }
          //]
        },
        
      ]
    },
    { path: '/auth/login', title: 'Logout', icon: 'box', type: 'link', active: false }
  ];

}
