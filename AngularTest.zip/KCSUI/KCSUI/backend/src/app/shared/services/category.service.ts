import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs';
import { map } from 'rxjs/Operators';
import { Global } from '../global';
import { CategoryModel } from '../models/category.model';
import { DataService } from './data.service';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  //model = new CategoryModel();
  private httpOptions = { headers: new HttpHeaders().set('Content-Type', 'application/json') };
  constructor(private _dataService: DataService, private _toastr: ToastrService, private http: HttpClient) { }


  private GetAllCategory(): Observable<CategoryModel[]> {
    let data = this._dataService.get(Global.BASE_USER_ENDPOINT + "Categoryy/GetCategoryList");
    return data;
  }
  getAllCategory() {
    return this.GetAllCategory();
  }
  SaveMembershipCategory(model: CategoryModel) {
    let data = this._dataService.post(Global.BASE_USER_ENDPOINT + "Categoryy/Save/", model)
    return data;
  }
  saveMemCat(model: CategoryModel) {
    return this.SaveMembershipCategory(model)
  }
  UpdateMembershipCategory(model: CategoryModel) {
    let data = this._dataService.put(Global.BASE_USER_ENDPOINT + "Categoryy/Update/",  model)
    return data;
  }
  updateMemCat(model: CategoryModel) {
    return this.UpdateMembershipCategory(model)
  }
}
