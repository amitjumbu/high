export enum DbOperation {
    create = 1,
    update = 2,
    delete = 3,
    view = 4,
    changeStatus = 5
}
