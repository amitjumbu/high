import { Component, OnInit, Input, Output, EventEmitter, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
//import { ActionGroupTab, ActionItem, ActionType } from '../../../core/models/action-group';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { TopButtonBarService } from './top-btn.serrvice';
import { Router } from '@angular/router';
import { ActionGroupTab, ActionItem, ActionType } from '../../models/action-group';

@Component({
  selector: 'app-top-btn-group',
  templateUrl: './top-btn-group.component.html',
  styleUrls: ['./top-btn-group.component.css']
})
export class TopBtnGroupComponent implements OnInit, AfterViewInit {
  @Input() actionGroupConfig: ActionGroupTab[];
  @Output() action: EventEmitter<string> = new EventEmitter();
  @Input() withTab: boolean = true;
  @Input() ParentPageName: string = '';

  IsTosca: boolean;
  modalRef: NgbModalRef;

  private actionItemsMap: { [type: string]: ActionItem } = {};
  constructor(
    private topButtonBarService: TopButtonBarService,
    public modalService: NgbModal,
    private route: Router
  ) { }

  ngOnInit(): void {
    this.actionGroupConfig = JSON.parse(JSON.stringify(this.actionGroupConfig));
    this.actionGroupConfig.forEach(tab => {
      tab.actionGroups.forEach(group => {
        group.forEach(actionItem => this.actionItemsMap[actionItem.type] = actionItem);
      });
    });
  }

  actionHandler(type: ActionType): void {
    this.action.emit(type);
    this.topButtonBarService.action(type);
  }

  enableAction(type: ActionType): void {
    this.actionItemsMap[type].disabled = false;
  }

  disableAction(type: ActionType): void {
    this.actionItemsMap[type].disabled = true;
  }

  showAction(type: ActionType): void {
    this.actionItemsMap[type].hidden = false;
  }

  hideAction(type: ActionType): void {
    this.actionItemsMap[type].hidden = true;
  }

  hideTab(lable: string): void {
    this.actionGroupConfig.find(tab => tab.label === lable).hidden = true;
  }

  showTab(lable: string): void {
    this.actionGroupConfig.find(tab => tab.label === lable).hidden = false;
  }

  activateAction(type: ActionType): void {
    this.actionItemsMap[type].active = true;
  }

  inactivateAction(type: ActionType): void {
    this.actionItemsMap[type].active = false;
  }


  ngAfterViewInit() {

    //Home buttons Hide Globally
    this.hideAction('back');
    this.hideAction('refresh');
    this.hideAction('cancel');
    this.hideAction('showDetails');
    this.hideAction('issue');
    this.hideAction('notification');
    this.hideAction('setupWizard');
    this.hideAction('language');
    this.hideAction('alerts');
    this.hideAction('profile');
    this.hideAction('share');
    this.hideAction('feedback');
    this.hideAction('deleteSelectedRow');
    this.hideAction('copy');
    this.hideAction('homeCancel');
    this.hideAction('save');
    this.hideAction('addRow');

    //Data buttons Hide Globally
    this.hideAction('import');
    this.hideAction('filter');
    this.hideAction('void');

    //Action buttons Hide Globally
    this.hideAction('approve');
    this.hideAction('declined');
    this.hideAction('accept');
    this.hideAction('lock');
    this.hideAction('unlock');
    this.hideAction('resetPassword');
    this.hideAction('edittype');
    this.hideAction('addnewtype');
    this.hideAction('flex');
    this.hideAction('publish');
    this.hideAction('document');

    //View buttons Hide Globally
   
      this.hideAction('notification');
      this.hideAction('setupWizard');
      this.hideAction('language');
      this.hideAction('userName');
   
      this.hideAction('issue');
      this.hideAction('alerts');
    
  }


}
