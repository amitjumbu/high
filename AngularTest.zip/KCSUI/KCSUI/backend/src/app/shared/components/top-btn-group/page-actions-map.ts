//import { ActionGroupTab, ActionItem } from "../../../core/models/action-group";

import { ActionGroupTab, ActionItem } from "../../models/action-group";

const actionItemsTypeMap = {
  add: { label: 'Addnew', colorClass: 'btn-outline-primary', iconClass: 'fa fa-plus', type: 'add' },
  edit: { label: 'Edit', colorClass: 'btn-outline-primary', iconClass: 'fa fa-pencil', type: 'edit' },
  delete: { label: 'Delete', colorClass: 'btn-outline-danger', iconClass: 'fa fa-trash-o', type: 'delete' },
  issue: { label: 'key_Issue', colorClass: 'btn-outline-danger', iconClass: 'fa fa-info', type: 'issue' },
  profile: {
    label: 'key_Profile', colorClass: 'btn-outline-primary', iconClass: 'fa fa-user-o', type: 'profile', menu: [
      //{ label: 'key_UserName', iconClass: 'fa fa-user-o', type: 'userName' },
      { label: 'key_ChangePassword', iconClass: 'fa fa-key', type: 'changePassword' },
      { label: 'key_Logout', iconClass: 'fa fa-power-off', type: 'logout' }
    ]
  },
  export: { label: 'Export', colorClass: 'btn-outline-success', iconClass: 'fa fa-file-excel-o', type: 'export' },
  active: { label: 'key_Active', colorClass: 'btn-outline-success', iconClass: 'fa fa-check', type: 'active' },
  inactive: { label: 'key_Inactive', colorClass: 'btn-outline-warning', iconClass: 'fa fa-exclamation', type: 'inactive' },
  resetPassword: { label: 'key_ResetPassword', colorClass: 'btn-outline-primary', iconClass: 'fa fa-key', type: 'resetPassword' },
  approve: { label: 'key_Approve', colorClass: 'btn-outline-success', iconClass: 'fa fa-check-square', type: 'approve' },
  accept: { label: 'key_Accecpt', colorClass: 'btn-outline-success', iconClass: 'fa fa-check-square-o', type: 'accept' },
  unlock: { label: 'key_Unlock', colorClass: 'btn-outline-success', iconClass: 'fa fa-unlock-alt', type: 'unlock' },
  declined: { label: 'key_Declined', colorClass: 'btn-outline-danger', iconClass: 'fa fa-ban', type: 'declined' },
  notification: { label: 'key_Notification', colorClass: 'btn-outline-primary', iconClass: 'fa fa-bell-o', type: 'notification' },
  alerts: { label: 'key_Alerts', colorClass: 'btn-outline-primary', iconClass: 'fa fa-bell-o', type: 'alerts' },
  setupWizard: { label: 'key_SetupWizard', colorClass: 'btn-outline-primary', iconClass: 'fa fa-cogs', type: 'setupWizard' },
  language: {
    label: 'key_Language', colorClass: 'btn-outline-primary', iconClass: 'fa fa-language', type: 'language', menu: [
      { label: 'key_English', iconClass: 'fa fa-flag-o', type: 'english' },
      { label: 'key_Hindi', iconClass: 'fa fa-flag-o', type: 'hindi' }
    ]
  },
  showDetails: { label: 'key_ShowDetails', colorClass: 'btn-outline-primary', iconClass: 'fa fa-eye', type: 'showDetails' },
  
  refresh: { label: 'key_Refresh', colorClass: 'btn-outline-success', iconClass: 'fa fa-refresh', type: 'refresh' },
  filter: { label: 'key_Filter', colorClass: 'btn-outline-primary', iconClass: 'fa fa-filter', type: 'filter' },
  
  edittype: { label: 'key_Edittype', colorClass: 'btn-outline-primary', iconClass: 'fa fa-pencil', type: 'edittype' },
  addnewtype: { label: 'key_Addnewtype', colorClass: 'btn-outline-primary', iconClass: 'fa fa-plus', type: 'addnewtype' },
  view: { label: 'key_Viewimportstatus', colorClass: 'btn-outline-success', iconClass: 'fa fa-file-excel-o', type: 'view' },
  import: { label: 'key_Import', colorClass: 'btn-outline-success', iconClass: 'fa fa-upload', type: 'import' },
  addNew: { label: 'Addnew', colorClass: 'btn-outline-primary', iconClass: 'fa fa-plus', type: 'addNew' },
  addRow: { label: 'key_AddRows', colorClass: 'btn-outline-primary', iconClass: 'fa fa-plus', type: 'addRow' },
  
  deleteSelectedRow: { label: 'key_DeleteSelectedRow', colorClass: 'btn-outline-danger', iconClass: 'fa fa-trash', type: 'deleteSelectedRow' },
  
  flex: { label: 'key_Flex', colorClass: 'btn-outline-warning', iconClass: 'fa fa-shower', type: 'flex' },
  
  lock: { label: 'key_Lock', colorClass: 'btn-outline-danger', iconClass: 'fa fa-lock', type: 'lock' },
  
  graph: { label: 'key_Graph', colorClass: 'btn-outline-success', iconClass: 'fa fa-pie-chart', type: 'graph' },
  
  void: { label: 'key_void', colorClass: 'btn-outline-success', iconClass: 'fa fa-dot-circle-o', type: 'void' },

  cancel: { label: 'key_cancel', colorClass: 'btn-outline-danger', iconClass: 'fa fa-times', type: 'cancel' },
  homeCancel: { label: 'key_cancel', colorClass: 'btn-outline-danger', iconClass: 'fa fa-times', type: 'homeCancel' },
  save: { label: 'Save', colorClass: 'btn-outline-success', iconClass: 'fa fa-floppy-o', type: 'save' },
  
  document: {
    label: 'key_document', colorClass: 'btn-outline-primary', iconClass: 'fa fa-book', type: 'document'},
  
  copy: { label: 'key_copy', colorClass: 'btn-outline-primary', iconClass: 'fa fa-files-o', type: 'copy' },  
  feedback: { label: 'key_Feedback', colorClass: 'btn-outline-primary', iconClass: 'fa fa-comments', type: 'feedback' },
  share: { label: 'key_Share', colorClass: 'btn-outline-primary', iconClass: 'fa fa-share-alt', type: 'share' },  
  back: { label: 'key_Back', colorClass: 'btn-outline-primary', iconClass: 'fa fa-arrow-left', type: 'back' },
}

/**
 * 
 * @param actionGroupsKeys ex. - "add,edit,delete|issue,profile"
 */
function getActionGroups(actionGroupsKeys: string): ActionItem[][] {
  if (!actionGroupsKeys) {
    return [];
  }
  const groups = actionGroupsKeys.split('|');
  return groups.map(group => {
    const actions = group.split(',');
    if (actions.length) {
      return actions.map(type => actionItemsTypeMap[type.trim()]);
    }
    return [];
  });
}

export function getGlobalRibbonActions(): ActionGroupTab[] {
  return [
    {
      label: 'Home',
      actionGroups: getActionGroups('back,add,addRow,edit,copy,showDetails,deleteSelectedRow,save,homeCancel,delete,refresh|issue,notification,setupWizard,language,alerts,profile,share,feedback'),      
    },
    {
      label: 'Data',
      actionGroups: getActionGroups('import,filter,void,export')
    },
    {
      label: 'key_Action',
      actionGroups: getActionGroups('approve,declined,accept,active,inactive,lock,unlock,resetPassword,edittype,addnewtype,flex,cancel,document')
    },
    {
      label: 'key_View',
      actionGroups: getActionGroups('view,graph')
    }

  ]
}

