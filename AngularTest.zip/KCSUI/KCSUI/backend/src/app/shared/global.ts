export class Global {
// For Localhost 
public static BASE_USER_ENDPOINT = 'https://localhost:44350/api/';


// For Live Serve
//public static BASE_USER_ENDPOINT = '';

}
