import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BreadcrumbComponent } from './components/breadcrumb/breadcrumb.component';
import { FeatherIconsComponent } from './components/feather-icons/feather-icons.component';
import { FooterComponent } from './components/footer/footer.component';
import { HeaderComponent } from './components/header/header.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { ContentLayoutComponent } from './layout/content-layout/content-layout.component';
import { RouterModule } from '@angular/router';
import { TopBtnGroupComponent } from './components/top-btn-group/top-btn-group.component';
import { MatTabsModule } from '@angular/material/tabs';

@NgModule({
  declarations: [BreadcrumbComponent, FeatherIconsComponent, FooterComponent, HeaderComponent, SidebarComponent, ContentLayoutComponent, TopBtnGroupComponent],
  imports: [
    CommonModule,
    RouterModule,
    MatTabsModule
  ],
  exports: [FeatherIconsComponent, TopBtnGroupComponent]
})
export class SharedModule { }
