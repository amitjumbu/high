import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { MatTabGroup } from '@angular/material/tabs';

import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { getGlobalRibbonActions } from '../../../shared/components/top-btn-group/page-actions-map';
import { TopBtnGroupComponent } from '../../../shared/components/top-btn-group/top-btn-group.component';
import { CategoryModel } from '../../../shared/models/category.model';
import { AddCategoryComponent } from './add-category/add-category.component';
import { EditCategoryComponent } from './edit-category/edit-category.component';
import { ListCategoryComponent } from './list-category/list-category.component';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.scss']
})
export class CategoryComponent implements OnInit, AfterViewInit{
  
  @ViewChild(ListCategoryComponent) listCategoryComponent: ListCategoryComponent;  
  membershipSelected = new CategoryModel();
  tab1: boolean = true;
  tab1Data: boolean = true;
  @ViewChild('tabGroupA') tabGroup: MatTabGroup;
  @ViewChild('btnBar') btnBar: TopBtnGroupComponent;
  actionGroupConfig;

  tabChange($event) {
    if ($event.index === 0) {
      this.tab1Data = true;
    }
  }

  actionHandler(type) {
    if (type === "add") {
      this.modalRef = this.modalService.open(AddCategoryComponent, { size: 'md', backdrop: 'static' });
      this.modalRef.result.then((result) => {
        this.listCategoryComponent.getCategoryList();        
      }), (reason) => {
      };
    }
    else if (type === "edit") {
      if (this.listCategoryComponent.selection.selected.length <= 0) {
        this._toastr.warning("Please select record to edit");
        return;
      }
      else if (this.listCategoryComponent.selection.selected.length > 1
        || this.listCategoryComponent.selection.selected == null) {
        this._toastr.warning("Please select one record to edit");
        return;
      }
      else {
        this.modalRef = this.modalService.open(EditCategoryComponent, { size: 'md', backdrop: 'static' });
        this.membershipSelected = this.listCategoryComponent.selection.selected[0];
        this.modalRef.componentInstance.data = this.membershipSelected;
        this.modalRef.result.then((result) => {
          this.listCategoryComponent.getCategoryList();
        }), (reason) => {
        };
      }     

    }
    else if (type === "delete") {

    }
    else if (type === "import") {

    }
    else if (type === "export") {

    }
  }

  modalRef: NgbModalRef;
  IsTosca: boolean;

  constructor(
    public modalService: NgbModal,
    private _toastr: ToastrService,
  ) { }

  ngOnInit(): void {
    
    this.actionGroupConfig = getGlobalRibbonActions();
  }

  ngAfterViewInit() {
    this.btnBar.hideTab('key_Action');
    this.btnBar.hideTab('key_View');
  }

}
