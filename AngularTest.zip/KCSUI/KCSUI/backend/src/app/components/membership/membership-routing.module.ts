import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddCategoryComponent } from './category/add-category/add-category.component';
import { CategoryComponent } from './category/category.component';
import { EditCategoryComponent } from './category/edit-category/edit-category.component';
import { ListCategoryComponent } from './category/list-category/list-category.component';


const routes: Routes = [
  { path: 'category', component: CategoryComponent }
    //path: '', children: [
    //  { path: 'category/add-category', component: AddCategoryComponent },
    //  { path: 'category/edit-category', component: EditCategoryComponent },
    //  { path: 'category/list-category', component: ListCategoryComponent }
    //]
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MembershipRoutingModule { }
