import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { Global } from '../../../../shared/global';
import { CategoryModel } from '../../../../shared/models/category.model';
import { CategoryService } from '../../../../shared/services/category.service';
import { DataService } from '../../../../shared/services/data.service';
@Component({
  selector: 'app-add-category',
  templateUrl: './add-category.component.html',
  styleUrls: ['./add-category.component.scss']
})
  
export class AddCategoryComponent implements OnInit {
  itemList = [];
  selectedItems = [];
  settings = {};
  model = new CategoryModel();
  constructor(
    public activeModal: NgbActiveModal,
    public categoryService: CategoryService,
    private _toastr: ToastrService,
    private _dataService: DataService
  ) { }

  ngOnInit(): void {
    this.itemList  = [
      { "id": 1, "itemName": "Regular" },
      { "id": 2, "itemName": "Corporate" }
    ];
    
    this.settings = {
      enableSearchFilter: true,
      addNewItemOnFilter: true,
      singleSelection: true,
      text: "Select"
    };            
  }
  
  saveMembershipCategory() {
    this.setDataModel();
    this.categoryService.saveMemCat(this.model).subscribe(result => {
      if (result.isSuccess) {
        this._toastr.success('Saved successfully');
        this.close();
      }
      else {
        this._toastr.error('wrong');        
      }
    });
  }
  //onsave() {
  //  this.setDataModel();
  //  this._dataService.post(Global.BASE_USER_ENDPOINT + "Categoryy/Save/", this.model).subscribe(res => {
  //    if (res.isSuccess) {
  //      this._toastr.info('Saved successfully');
  //      this.close();
  //    } else {
  //      this._toastr.error('wrong'); 
  //    }
  //  });

  //}
  setDataModel() {
    this.model.CategoryType = this.selectedItems.map(function (x) { return x.itemName; })[0];
    //this.model.MembershipName = this.membershipName;;
    //this.model.Description = this.description;
  }

  close() {
    this.activeModal.close();
  }
}
