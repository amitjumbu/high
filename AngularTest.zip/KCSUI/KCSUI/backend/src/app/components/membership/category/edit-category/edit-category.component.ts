import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { CategoryModel } from '../../../../shared/models/category.model';
import { CategoryService } from '../../../../shared/services/category.service';
import { DataService } from '../../../../shared/services/data.service';

@Component({
  selector: 'app-edit-category',
  templateUrl: './edit-category.component.html',
  styleUrls: ['./edit-category.component.scss']
})
export class EditCategoryComponent implements OnInit {
  itemList = [];
  selectedItems = [];
  settings = {};
  selectedModel = new CategoryModel();  
  @Input() public data;

  constructor(
    public activeModal: NgbActiveModal,
    public categoryService: CategoryService,
    private _toastr: ToastrService,
    private _dataService: DataService
  ) { }

  ngOnInit(): void {
    this.itemList = [
      { "id": 1, "itemName": "Regular" },
      { "id": 2, "itemName": "Corporate" }
    ];

    this.settings = {
      enableSearchFilter: true,
      addNewItemOnFilter: true,
      singleSelection: true,
      text: "Select"
    };
    this.setEditMembershipCategory();
  }
  setEditMembershipCategory() {
    this.selectedModel.MembershipName = this.data.membershipName;
    this.selectedModel.Description = this.data.description;
    this.selectedItems = [{ id: this.data.id, itemName: this.data.categoryType }]//this.data.categoryType;
    this.selectedModel.Id = this.data.id;
  }

  updateMembershipCategory() {
    this.setDataModel();
    this.categoryService.updateMemCat(this.selectedModel).subscribe(result => {
      if (result.isSuccess) {
        this._toastr.success('Updated successfully');
        this.close();
      }
      else {
        this._toastr.error('Somthing Went Wrong.');
      }
      
    });
  }  
  
  setDataModel() {
    this.selectedModel.CategoryType = this.selectedItems.map(function (x) { return x.itemName; })[0];
  }

  close() {
    this.activeModal.close();
  }

}
