import { Component, ViewChild, OnInit, Output, EventEmitter } from '@angular/core';

import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

import { SelectionModel } from '@angular/cdk/collections';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { ToastrService } from 'ngx-toastr';

//import { AddCommentComponent } from 'app/modules/inventory/pages/current-on-hand-inventory/add-comment/add-comment.component';
import { ResizeEvent } from 'angular-resizable-element';
import { CategoryModel } from '../../../../shared/models/category.model';
import { CategoryService } from '../../../../shared/services/category.service';

//import { ToastrService } from 'ngx-toastr';
//import { AuthService } from '../../../../../core';
//import { ConfirmDeleteTabledataPopupComponent } from '../../../../../shared/components/confirm-delete-tabledata-popup/confirm-delete-tabledata-popup.component';


@Component({
  selector: 'app-list-category',
  templateUrl: './list-category.component.html',
  styleUrls: ['./list-category.component.scss']
})
export class ListCategoryComponent implements OnInit {

  displayedColumns = ['selectRow', 'membershipName', 'categoryType', 'description'];
  displayedColumnsReplace = ['selectRow', 'Membership Name', 'Category Type', 'Description'];
  dataSource;
  selection = new SelectionModel<CategoryModel>(true, []);
  filterValue = "";
  @Output('selectedMembership') selectedMembership = new EventEmitter<CategoryModel[]>();
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort; 
  modalRef: NgbModalRef;
  selectRow: any;
  constructor(public modalService: NgbModal, public categoryService: CategoryService) { }

  //openPopup(action) {
  //  if (action === "addComment") {
  //    this.modalRef = this.modalService.open(AddCommentComponent, { size: 'md', backdrop: 'static' });
  //  }
  //}

  ngOnInit() {
    this.selectRow = 'selectRow';
    this.dataSource = new MatTableDataSource<CategoryModel>();
    this.getCategoryList();
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.paginator.showFirstLastButtons = true;
  }

  onSelectionChange(row: CategoryModel, checked: boolean) {
    row.IsSelected = checked;
    this.selection.toggle(row);
    this.selectedMembership.emit(this.selection.selected);
  }

  applyFilter(filterText: string) {
    filterText = filterText.trim(); // Remove whitespace
    filterText = filterText.toLowerCase(); // Datasource defaults to lowercase matches
    this.dataSource.filter = filterText
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.lenght;
    return numSelected === numRows;
    //return numSelected;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => {
        this.selection.select(row);
        row.isSelected = true;
        this.selectedMembership.emit(this.selection.selected);
      });
    //this.isAllSelected() ?
    //  this.selection.clear() :
    //  this.dataSource.data.forEach(row => this.selection.select(row));
  }
  
  getCategoryList() {
    this.selection.clear();
    this.categoryService.getAllCategory().subscribe(res => {
      this.dataSource.data = res;
    });
      
  }

  onResizeEnd(event: ResizeEvent, columnName): void {
    if (event.edges.right) {
      const cssValue = event.rectangle.width + 'px';
      const columnElts = document.getElementsByClassName('mat-column-' + columnName);
      for (let i = 0; i < columnElts.length; i++) {
        const currentEl = columnElts[i] as HTMLDivElement;
        currentEl.style.width = cssValue;
      }
    }
  }

}
