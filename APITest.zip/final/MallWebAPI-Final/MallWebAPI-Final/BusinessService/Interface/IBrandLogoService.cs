﻿using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.Master.ResponseDto;
using System.Collections.Generic;

namespace BusinessService.Interface
{
    public interface IBrandLogoService
    {
        ResultDto<long> Add(BrandLogoRequest viewModel);
        ResultDto<long> Update(BrandLogoRequest viewModel);
        ResultDto<long> Delete(int ID);
        ResultDto<BrandLogoResponse> GetbyId(int TypeId);
        ResultDto<IEnumerable<BrandLogoResponse>> GetAll();
    }
}
