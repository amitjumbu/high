﻿using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.Master.ResponseDto;
using System.Collections.Generic;

namespace BusinessService.Interface
{
   public interface ICategoryService
    {
        ResultDto<long> Add(CategoryListRequest viewModel);
        ResultDto<long> Update(CategoryListRequest viewModel);
        //ResultDto<long> Delete(int ID);
        //ResultDto<CustomerMasterResponse> GetbyId(int TypeId);
        IEnumerable<CategoryListResponse> GetCategoryList();
    }
}
