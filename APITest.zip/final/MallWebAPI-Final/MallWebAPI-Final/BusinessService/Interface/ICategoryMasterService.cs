﻿using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.Master.ResponseDto;
using System.Collections.Generic;

namespace BusinessService.Interface
{
    public interface ICategoryMasterService
    {
        ResultDto<long> Add(CategoryMasterRequest viewModel);
        ResultDto<long> Update(CategoryMasterRequest viewModel);
        ResultDto<long> Delete(int ID);
        ResultDto<CategoryMasterResponse> GetbyId(int TypeId);
        ResultDto<IEnumerable<CategoryMasterResponse>> GetAll();
    }
}
