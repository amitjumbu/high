﻿using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.Master.ResponseDto;
using System.Collections.Generic;

namespace BusinessService.Interface
{
    public interface ITagMasterService
    {
        ResultDto<long> Add(TagMasterRequest viewModel);
        ResultDto<long> Update(TagMasterRequest viewModel);
        ResultDto<long> Delete(long Id);
        ResultDto<TagMasterResponse> GetById(long Id);
        ResultDto<IEnumerable<TagMasterResponse>> GetAll();
    }
}
