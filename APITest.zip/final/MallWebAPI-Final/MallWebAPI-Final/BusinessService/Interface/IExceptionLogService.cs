﻿using BusinessEntities.Mall.Common;

namespace BusinessService.Interface
{
    public interface IExceptionLogService
    {
        long Add(LogEntryRequest viewModel);
    }
}
