﻿using BusinessEntities.Mall.Common;
using BusinessService.Interface;
using Repositories.Interface;

namespace BusinessService.Implementation
{
    public class ExceptionLogService : IExceptionLogService
    {
        private readonly IExceptionLogRepository _iExceptionLogRepository;
      
        public ExceptionLogService(IExceptionLogRepository repository)
        {
            _iExceptionLogRepository = repository;
        }

        public long Add(LogEntryRequest viewModel)
        {
            var res = _iExceptionLogRepository.Add(viewModel);
            return res;
        }
    }
}
