﻿using AutoMapper;
using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.Master.ResponseDto;
using BusinessService.Interface;
using Repositories.Interface;
using Repositories.Mall;
using System.Collections.Generic;

namespace BusinessService.Implementation
{
    public class TagMasterService : ITagMasterService
    {
        private readonly ITagMasterRepository _iTagMasterRepository;
        private IMapper _mapper;
        public TagMasterService(IMapper mapper, ITagMasterRepository repository)
        {
            _mapper = mapper;
            _iTagMasterRepository = repository;
        }

        public ResultDto<long> Add(TagMasterRequest viewModel)
        {
            var res = new ResultDto<long>
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iTagMasterRepository.Add(viewModel);
            if (response > 0)
            {
                res.IsSuccess = true;
                res.Data = response;
            }
            else
            {
                res.Errors.Add("Tag name already exists !!");
            }
            return res;
        }
        public ResultDto<long> Update(TagMasterRequest viewModel)
        {
            var res = new ResultDto<long>
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iTagMasterRepository.Update(viewModel);
            if (response > 0)
            {
                res.IsSuccess = true;
                res.Data = response;
            }
            else
            {
                res.Errors.Add("Tag name already exists !!");
            }
            return res;
        }
        public ResultDto<long> Delete(long Id)
        {
            var res = new ResultDto<long>
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iTagMasterRepository.Delete(Id);
            if (response > 0)
            {
                res.IsSuccess = true;
                res.Data = response;
            }
            else
            {
                res.Errors.Add("Record not found !!");
            }
            return res;
        }

        public ResultDto<TagMasterResponse> GetById(long Id)
        {
            var res = new ResultDto<TagMasterResponse>
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iTagMasterRepository.GetById(Id);
            if (response == null)
            {
                res.Errors.Add("No Record Found !!");
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<DBTagMaster, TagMasterResponse>(response);
            }
            return res;
        }

        public ResultDto<IEnumerable<TagMasterResponse>> GetAll()
        {
            var res = new ResultDto<IEnumerable<TagMasterResponse>>
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iTagMasterRepository.GetAll();
            if (response == null)
            {
                res.Errors.Add("No Record Found !!");
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBTagMaster>, IEnumerable<TagMasterResponse>>(response);
            }
            return res;
        }
    }
}
