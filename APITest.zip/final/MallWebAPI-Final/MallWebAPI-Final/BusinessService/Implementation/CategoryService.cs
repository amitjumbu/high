﻿using AutoMapper;
using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.Master.ResponseDto;
using BusinessService.Interface;
using Repositories.Interface;
using Repositories.Mall;
using System.Collections.Generic;

namespace BusinessService.Implementation
{
   public class CategoryService : ICategoryService
    {
        private readonly ICategoryRepository _iCategoryRepository;
        private IMapper _mapper;
        public CategoryService(IMapper mapper, ICategoryRepository repository)
        {
            _iCategoryRepository = repository;
            _mapper = mapper;
        }

        public ResultDto<long> Add(CategoryListRequest viewModel)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iCategoryRepository.Add(viewModel);
            if (response == -1)
            {
                res.Errors.Add("allready exists");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = response;
                return res;
            }
        }
        public ResultDto<long> Update(CategoryListRequest viewModel)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iCategoryRepository.Update(viewModel);
            if (response == -1)
            {
                res.Errors.Add("Id not exists");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = response;
                return res;
            }
        }
        //public ResultDto<long> Delete(int ID)
        //{
        //    var res = new ResultDto<long>()
        //    {
        //        IsSuccess = false,
        //        Data = 0,
        //        Errors = new List<string>()
        //    };
        //    var response = _iCustomerMasterRepository.Delete(ID);
        //    if (response == -1)
        //    {
        //        res.Errors.Add("Email Id not exists");
        //        return res;
        //    }
        //    else
        //    {
        //        res.IsSuccess = true;
        //        res.Data = response;
        //        return res;
        //    }
        //}
        //public ResultDto<CustomerMasterResponse> GetbyId(int Id)
        //{
        //    var res = new ResultDto<CustomerMasterResponse>()
        //    {
        //        IsSuccess = false,
        //        Data = null,
        //        Errors = new List<string>()
        //    };
        //    var response = _iCustomerMasterRepository.GetbyId(Id);
        //    if (response == null)
        //    {
        //        res.Errors.Add("An Error Occured");
        //        return res;
        //    }
        //    else
        //    {
        //        res.IsSuccess = true;
        //        res.Data = _mapper.Map<DBCustomerMaster, CustomerMasterResponse>(response);
        //        return res;
        //    }
        //}


        public IEnumerable<CategoryListResponse> GetCategoryList()
        {
            var response = _iCategoryRepository.GetCategoryList();
            var res = _mapper.Map<IEnumerable<DBCategoryList>, IEnumerable<CategoryListResponse>>(response);
            return res;
        }        
        
    }
}
