﻿using BusinessEntities.Mall.Master.RequestDto;
using Repositories.Mall;
using System.Collections.Generic;

namespace Repositories.Interface
{
    public interface IColorMasterRepository
    {
        long Add(ColorMasterRequest viewModel);
        long Update(ColorMasterRequest viewModel);
        long Delete(long Id);
        DBColorMaster GetById(long Id);
        IEnumerable<DBColorMaster> GetAll();
    }
}
