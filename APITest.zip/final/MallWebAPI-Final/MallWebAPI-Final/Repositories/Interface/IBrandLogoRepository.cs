﻿using BusinessEntities.Mall.Master.RequestDto;
using Repositories.Mall;
using System.Collections.Generic;

namespace Repositories.Interface
{
    public interface IBrandLogoRepository
    {
        long Add(BrandLogoRequest viewModel);
        long Update(BrandLogoRequest viewModel);
        long Delete(int ID);
        DBBrandLogo GetbyId(int TypeId);
        IEnumerable<DBBrandLogo> GetAll();
    }
}
