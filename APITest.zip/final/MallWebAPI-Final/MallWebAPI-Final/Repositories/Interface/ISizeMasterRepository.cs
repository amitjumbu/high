﻿using BusinessEntities.Mall.Master.RequestDto;
using Repositories.Mall;
using System.Collections.Generic;

namespace Repositories.Interface
{
    public interface ISizeMasterRepository
    {
        long Add(SizeMasterRequest viewModel);
        long Update(SizeMasterRequest viewModel);
        long Delete(long Id);
        DBSizeMaster GetById(long Id);
        IEnumerable<DBSizeMaster> GetAll();
    }
}
