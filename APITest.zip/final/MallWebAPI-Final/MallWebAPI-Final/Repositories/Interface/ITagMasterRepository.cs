﻿using BusinessEntities.Mall.Master.RequestDto;
using Repositories.Mall;
using System;
using System.Collections.Generic;
using System.Text;

namespace Repositories.Interface
{
   public interface ITagMasterRepository
    {
        long Add(TagMasterRequest viewModel);
        long Update(TagMasterRequest viewModel);
        long Delete(long Id);
        DBTagMaster GetById(long Id);
        IEnumerable<DBTagMaster> GetAll();
    }
}
