﻿using BusinessEntities.Mall.Master.RequestDto;
using Repositories.Mall;
using System.Collections.Generic;

namespace Repositories.Interface
{
    public interface ICategoryRepository
    {
        long Add(CategoryListRequest viewModel);
        long Update(CategoryListRequest viewModel);
        //long Delete(int ID);
        //DBCustomerMaster GetbyId(int Id);
        IEnumerable<DBCategoryList> GetCategoryList();
    }
}
