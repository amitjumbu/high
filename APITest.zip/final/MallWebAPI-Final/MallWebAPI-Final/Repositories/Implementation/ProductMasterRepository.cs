﻿using BusinessEntities.Mall.Master.RequestDto;
using Microsoft.EntityFrameworkCore;
using Repositories.dbContext;
using Repositories.Interface;
using Repositories.Mall;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace Repositories.Implementation
{
    public class ProductMasterRepository : IProductMasterRepository
    {
        protected AppliactionDbContext _Context;
        public ProductMasterRepository(AppliactionDbContext context)
        {
            _Context = context;
        }
        public DBProductMaster Add(ProductMasterRequest viewModel)
        {
                DBProductMaster lst = _Context.ProductMasters.FromSql("InsertProductMaster @Name,@Title,@Code,@Price,@SalePrice,@ShortDetails,@Description,@Quantity,@Discount,@IsNew,@IsSale,@CategoryId,@ColorId,@SizeId,@TagId,@CreatedBy",
                     new SqlParameter("@Name", viewModel.Name),
                     new SqlParameter("@Title", viewModel.Title),
                     new SqlParameter("@Code", viewModel.Code),
                     new SqlParameter("@Price", viewModel.Price),
                     new SqlParameter("@SalePrice", viewModel.SalePrice),
                     new SqlParameter("@ShortDetails", viewModel.ShortDetails),
                     new SqlParameter("@Description", viewModel.Description),
                     new SqlParameter("@Quantity", viewModel.Quantity),
                     new SqlParameter("@Discount", viewModel.Discount),
                     new SqlParameter("@IsNew", viewModel.IsNew),
                     new SqlParameter("@IsSale", viewModel.IsSale),
                     new SqlParameter("@CategoryId", viewModel.CategoryId),
                     new SqlParameter("@ColorId", viewModel.ColorId),
                     new SqlParameter("@SizeId", viewModel.SizeId),
                     new SqlParameter("@TagId", viewModel.TagId),
                     new SqlParameter("@CreatedBy", viewModel.CreatedBy)
                 ).FirstOrDefault();
          
            return lst;
        }
        public DBProductMaster Update(ProductMasterRequest viewModel)
        {
            DBProductMaster lst = _Context.ProductMasters.FromSql("UpdateProductMaster @Id,@Name,@Title,@Code,@Price,@SalePrice,@ShortDetails,@Description,@Quantity,@Discount,@IsNew,@IsSale,@CategoryId,@ColorId,@SizeId,@TagId,@ModifiedBy",
                     new SqlParameter("@Id", viewModel.Id),
                     new SqlParameter("@Name", viewModel.Name),
                     new SqlParameter("@Title", viewModel.Title),
                     new SqlParameter("@Code", viewModel.Code),
                     new SqlParameter("@Price", viewModel.Price),
                     new SqlParameter("@SalePrice", viewModel.SalePrice),
                     new SqlParameter("@ShortDetails", viewModel.ShortDetails),
                     new SqlParameter("@Description", viewModel.Description),
                     new SqlParameter("@Quantity", viewModel.Quantity),
                     new SqlParameter("@Discount", viewModel.Discount),
                     new SqlParameter("@IsNew", viewModel.IsNew),
                     new SqlParameter("@IsSale", viewModel.IsSale),
                     new SqlParameter("@CategoryId", viewModel.CategoryId),
                     new SqlParameter("@ColorId", viewModel.ColorId),
                     new SqlParameter("@SizeId", viewModel.SizeId),
                     new SqlParameter("@TagId", viewModel.TagId),
                     new SqlParameter("@ModifiedBy", viewModel.ModifiedBy)
                 ).FirstOrDefault();
            return lst;
        }
        public long Delete(int Id)
        {
            var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE  DeleteProductMaster @Id",
                    new SqlParameter("@Id", Id)
                );

            return lst;
        }
        public IEnumerable<DBProductMaster> GetAll()
        {
            List<DBProductMaster> lst = _Context.ProductMasters.FromSql("GetAllProductMaster").ToList();
            return lst;
        }
        public DBProductMaster GetbyId(int Id)
        {
            DBProductMaster lst = _Context.ProductMasters.FromSql("GetProductMasterbyId @Id",
             new SqlParameter("@Id", Id)
             ).FirstOrDefault();
            return lst;
        }
        public IEnumerable<DBProductListPictures> GetProductPicturebyId(int Id)
        {
            IEnumerable<DBProductListPictures> lst = _Context.ProductListPictures.FromSql("GetPicturesbyProductId @Id",
             new SqlParameter("@Id", Id)
             ).ToList();
            return lst;
        }
        public long AddImageMapping(ProductPictureMappingRequest viewModel)
        {
            var lst = _Context.Database.ExecuteSqlCommand("  EXECUTE  InsertProductPictureMapping @ProductId,@PictureName,@PicturePath,@IsDelete,@CreatedBy",
                 new SqlParameter("@ProductId", viewModel.ProductId),
                 new SqlParameter("@PictureName", viewModel.PictureName),
                 new SqlParameter("@PicturePath", viewModel.PicturePath),
                 new SqlParameter("@IsDelete", viewModel.IsDelete),
                 new SqlParameter("@CreatedBy", viewModel.CreatedBy)
             );

            return lst;
        }
        //for forntend data
        public IEnumerable<DBProductList> GetProductList()
        {
            List<DBProductList> lst = _Context.ProductLists.FromSql("GetProductList").ToList();
            return lst;
        }
        public IEnumerable<DBProductListColors> GetProductcolorsList()
        {
            List<DBProductListColors> lst = _Context.ProductListColors.FromSql("GetProductcolorsList").ToList();
            return lst;
        }
        public IEnumerable<DBProductListPictures> GetProductPicturesList()
        {
            List<DBProductListPictures> lst = _Context.ProductListPictures.FromSql("GetProductPicturesList").ToList();
            return lst;
        }
        public IEnumerable<DBProductListSizes> GetProductSizesList()
        {
            List<DBProductListSizes> lst = _Context.ProductListSizes.FromSql("GetProductSizesList").ToList();
            return lst;
        }
        public IEnumerable<DBProductListTags> GetProductTagsList()
        {
            List<DBProductListTags> lst = _Context.ProductListTags.FromSql("GetProductTagsList").ToList();
            return lst;
        }
        public IEnumerable<DBProductListVariants> GetProductVariantsList()
        {
            List<DBProductListVariants> lst = _Context.ProductListVariants.FromSql("GetProductVariantsList").ToList();
            return lst;
        }
    }
}
