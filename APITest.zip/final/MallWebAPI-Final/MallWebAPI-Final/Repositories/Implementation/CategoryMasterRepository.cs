﻿using BusinessEntities.Mall.Master.RequestDto;
using Microsoft.EntityFrameworkCore;
using Repositories.dbContext;
using Repositories.Interface;
using Repositories.Mall;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace Repositories.Implementation
{
    public class CategoryMasterRepository : ICategoryMasterRepository
    {
        protected AppliactionDbContext _Context;
        public CategoryMasterRepository(AppliactionDbContext context)
        {
            _Context = context;
        }

        public long Add(CategoryMasterRequest viewModel)
        {
                var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE  InsertCategoryMaster @Name,@Title,@ImagePath,@IsSave,@link,@CreatedBy",
                     new SqlParameter("@Name", viewModel.Name),
                     new SqlParameter("@Title", viewModel.Title),
                     new SqlParameter("@ImagePath", viewModel.ImagePath),
                     new SqlParameter("@IsSave", viewModel.IsSave),
                     new SqlParameter("@link", viewModel.Link),
                     new SqlParameter("@CreatedBy", viewModel.CreatedBy)
                 );
                return lst;
        }
        public long Update(CategoryMasterRequest viewModel)
        {
                var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE  UpdateCategoryMaster @Id,@Name,@Title,@ImagePath,@IsSave,@link,@ModifiedBy,@ModifiedOn",
                     new SqlParameter("@Id", viewModel.Id),
                     new SqlParameter("@Name", viewModel.Name),
                     new SqlParameter("@Title", viewModel.Title),
                     new SqlParameter("@ImagePath", viewModel.ImagePath),
                     new SqlParameter("@IsSave", viewModel.IsSave),
                     new SqlParameter("@link", viewModel.Link),
                     new SqlParameter("@ModifiedBy", viewModel.ModifiedBy),
                     new SqlParameter("@ModifiedOn", viewModel.ModifiedOn)
                 );
                return lst;
        }
        public long Delete(int Id)
        {
            var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE  DeleteCategoryMaster @Id",
                    new SqlParameter("@Id", Id)
                );

            return lst;
        }
        public IEnumerable<DBCategoryMaster> GetAll()
        {
            List<DBCategoryMaster> lst = _Context.CategoryMasters.FromSql("GetAllCategoryMaster").ToList();
            return lst;
        }
        public DBCategoryMaster GetbyId(int Id)
        {
            DBCategoryMaster lst = _Context.CategoryMasters.FromSql("GetCategoryMasterbyId @Id",
             new SqlParameter("@Id", Id)
             ).FirstOrDefault();
            return lst;
        }
    }
}
