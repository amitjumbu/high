﻿using BusinessEntities.Mall.Master.RequestDto;
using Microsoft.EntityFrameworkCore;
using Repositories.dbContext;
using Repositories.Interface;
using Repositories.Mall;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace Repositories.Implementation
{
    public class CustomerMasterRepository : ICustomerMasterRepository
    {
        protected AppliactionDbContext _Context;
        public CustomerMasterRepository(AppliactionDbContext context)
        {
            _Context = context;
        }
        public long Add(CustomerMasterRequest viewModel)
        {
                var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE  InsertCustomerMaster @FirstName,@LastName,@Email,@Password",
                     new SqlParameter("@FirstName", viewModel.FirstName),
                     new SqlParameter("@LastName", viewModel.LastName),
                     new SqlParameter("@Email", viewModel.EmailId),
                     new SqlParameter("@Password", viewModel.Password)
                 );
                return lst;
        }
        public long Update(CustomerMasterRequest viewModel)
        {
                var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE  UpdateCustomerMaster @UserId,@FirstName,@LastName,@Email,@Password,@ModifiedBy,@ModifiedOn",
                     new SqlParameter("@CustomerId", viewModel.Id),
                     new SqlParameter("@FirstName", viewModel.FirstName),
                     new SqlParameter("@LastName", viewModel.LastName),
                     new SqlParameter("@Email", viewModel.EmailId),
                     new SqlParameter("@Password", viewModel.Password),
                     new SqlParameter("@ModifiedBy", 1),
                     new SqlParameter("@ModifiedOn", Convert.ToDateTime(DateTime.Now.ToString()))
                 );
                return lst;
        }
        public long Delete(int Id)
        {
            var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE  DeleteCustomerMaster @CustomerId",
                    new SqlParameter("@CustomerId", Id)
                );

            return lst;
        }
        public IEnumerable<DBCustomerMaster> GetAll()
        {
            List<DBCustomerMaster> lst = _Context.CustomerMasters.FromSql("GetAllUsers").ToList();
            return lst;
        }
        public DBCustomerMaster GetbyId(int Id)
        {
            DBCustomerMaster lst = _Context.CustomerMasters.FromSql("GetUserbyId @CustomerId",
             new SqlParameter("@CustomerId", Id)
             ).FirstOrDefault();
            return lst;
        }
        public DBLogin Login(LoginRequest viewModel)
        {
            DBLogin lst = _Context.Logins.FromSql("GetCustomerLogin @UserName,@Password",
             new SqlParameter("@UserName", viewModel.UserName),
             new SqlParameter("@Password", viewModel.Password)
             ).FirstOrDefault();
            return lst;
        }
    }
}

