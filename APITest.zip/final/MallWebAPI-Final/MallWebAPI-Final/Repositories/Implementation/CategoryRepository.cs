﻿using BusinessEntities.Mall.Master.RequestDto;
using Microsoft.EntityFrameworkCore;
using Repositories.dbContext;
using Repositories.Interface;
using Repositories.Mall;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace Repositories.Implementation
{
    public class CategoryRepository : ICategoryRepository
    {
        protected AppliactionDbContext _Context;
        public CategoryRepository(AppliactionDbContext context)
        {
            _Context = context;
        }

        public long Add(CategoryListRequest viewModel)
        {
            var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE  InsertMembershipCategory @MembershipName,@CategoryType,@Description",
                     new SqlParameter("@MembershipName", viewModel.MembershipName),
                     new SqlParameter("@CategoryType", viewModel.CategoryType),
                     new SqlParameter("@Description", viewModel.Description)
                 );
            return lst;
        }

        public long Update(CategoryListRequest viewModel)
        {
            var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE  UpdateMembershipCategory @Id, @MembershipName,@CategoryType,@Description",
                     new SqlParameter("@Id", viewModel.Id),
                     new SqlParameter("@MembershipName", viewModel.MembershipName),
                     new SqlParameter("@CategoryType", viewModel.CategoryType),
                     new SqlParameter("@Description", viewModel.Description)
                 );
            return lst;
        }
        //public long Delete(int Id)
        //{
        //    var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE  DeleteCustomerMaster @CustomerId",
        //            new SqlParameter("@CustomerId", Id)
        //        );

        //    return lst;
        //}
        public IEnumerable<DBCategoryList> GetCategoryList()
        {
            List<DBCategoryList> lst = _Context.CategoryLists.FromSql("GetCategoryList").ToList();
            return lst;
        }

    }
}
