﻿using BusinessEntities.Mall.Master.RequestDto;
using Microsoft.EntityFrameworkCore;
using Repositories.dbContext;
using Repositories.Interface;
using Repositories.Mall;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace Repositories.Implementation
{
    public class TagMasterRepository : ITagMasterRepository
    {
        private AppliactionDbContext _Context;

        public TagMasterRepository(AppliactionDbContext context)
        {
            _Context = context;
        }

        public long Add(TagMasterRequest viewModel)
        {
                var obj = _Context.Database.ExecuteSqlCommand(" Execute InsertTagMaster @Name,@CreatedBy",
                    new SqlParameter("@Name", viewModel.Name),
                    new SqlParameter("@CreatedBy", viewModel.CreatedBy)
                    );

                return obj;
        }

        public long Update(TagMasterRequest viewModel)
        {
                var obj = _Context.Database.ExecuteSqlCommand(" Execute UpdateTagMaster @Id,@Name,@ModifiedBy",
                    new SqlParameter("@Id", viewModel.Id),
                    new SqlParameter("@Name", viewModel.Name),
                    new SqlParameter("@ModifiedBy", viewModel.ModifiedBy)
                    );

                return obj;
        }

        public long Delete(long Id)
        {
                var obj = _Context.Database.ExecuteSqlCommand("Execute DeleteTagMaster @Id,@ModifiedBy",
                    new SqlParameter("@Id", Id),
                     new SqlParameter("@ModifiedBy", 1)
                    );
                return obj;
        }

        public DBTagMaster GetById(long Id)
        {
            DBTagMaster obj = _Context.TagMasters.FromSql("GetTagMasterbyId  @Id",
                new SqlParameter("@Id", Id)
                ).FirstOrDefault();

            return obj;
        }

        public IEnumerable<DBTagMaster> GetAll()
        {
            IEnumerable<DBTagMaster> obj = _Context.TagMasters.FromSql("GetAllTagMaster").ToList();

            return obj;
        }

    }
}
