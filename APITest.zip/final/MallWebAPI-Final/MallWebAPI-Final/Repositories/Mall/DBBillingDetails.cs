﻿namespace Repositories.Mall
{
    public class DBBillingDetails:BaseEntity
    {
        public int id { get; set; }
        public int? customerId { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string phone { get; set; }
        public string EmailId { get; set; }
        public string address { get; set; }
        public int CountryId { get; set; }
        public string City { get; set; }
        public string state { get; set; }
        public string postalcode { get; set; }
    }
}
