﻿namespace Repositories.Mall
{
    public class DBDoPaymentMaster
    {
        public int Id { get; set; }
        public int BillDetailId { get; set; }
        public decimal SubTotalAmount { get; set; }
        public decimal ShippingAmount { get; set; }
        public int PaymentTypeId { get; set; }
        public int PaymentStatus { get; set; }
        public string OrderId { get; set; }
        public string PaymentDate { get; set; }
        public string Expecteddate { get; set; }
    }
}
