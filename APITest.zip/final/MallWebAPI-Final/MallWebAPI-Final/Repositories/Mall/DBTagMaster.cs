﻿namespace Repositories.Mall
{
    public class DBTagMaster :BaseEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
