﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace Repositories.Mall
{
    public class DBCategoryList
    {
        public int Id { get; set; }
        public string MembershipName { get; set; }        
        public string CategoryType { get; set; }
        public string Description { get; set; }
        
    }
}
