﻿namespace Repositories.Mall
{
    public class DBReportManageOrder
    {
        public string OrderId { get; set; }
        public string InvoiceNo { get; set; }
        public string PaymentStatus { get; set; }
        public string PaymentMethod { get; set; }
        public string OrderStatus { get; set; }
        public string PaymentDate { get; set; }
        public decimal SubTotalAmount { get; set; }
        public decimal ShippingAmount { get; set; }
        public decimal TotalAmount { get; set; }
    }
}
