﻿namespace Repositories.Mall
{
    public class DBProductListColors
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
    }
}
