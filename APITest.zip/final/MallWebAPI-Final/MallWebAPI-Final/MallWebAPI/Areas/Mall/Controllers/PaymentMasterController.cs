﻿using BusinessEntities.Mall.Master.RequestDto;
using BusinessService.Interface;
using MallWebAPI.Filter;
using Microsoft.AspNetCore.Mvc;
using Stripe;
using System;
using System.Collections.Generic;

namespace API.Areas.Mall.Controllers
{
    [ServiceFilter(typeof(DblExceptionFilter))]
    [Area("Mall")]
    [Produces("application/json")]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class PaymentMasterController : ControllerBase
    {
        private readonly IPaymentMasterService _iPaymentMasterService;

        public PaymentMasterController(IPaymentMasterService iPaymentMasterService)
        {
            _iPaymentMasterService = iPaymentMasterService;
        }

        [HttpGet]
        [ActionName("GetReportManageOrder")]
        public IActionResult GetReportManageOrder()
        {
            var res = _iPaymentMasterService.GetReportManageOrder();
            if (res.IsSuccess)
            {
                return Ok(res);
            }
            return NotFound(res);
        }

        [HttpGet]
        [ActionName("GetReportTransactionDetails")]
        public IActionResult GetReportTransactionDetails()
        {
            var res = _iPaymentMasterService.GetReportTransactionDetails();
            if (res.IsSuccess)
            {
                return Ok(res);
            }
            return NotFound(res);
        }

        [HttpGet]
        [ActionName("GetReportCashOnDelivery")]
        public IActionResult GetReportCashOnDelivery()
        {
            var res = _iPaymentMasterService.GetReportCashOnDelivery();
            if (res.IsSuccess)
            {
                return Ok(res);
            }
            return NotFound(res);
        }

        [HttpGet]
        [ActionName("GetReportInvoiceList")]
        public IActionResult GetReportInvoiceList()
        {
            var res = _iPaymentMasterService.GetReportInvoiceList();
            if (res.IsSuccess)
            {
                return Ok(res);
            }
            return NotFound(res);
        }

        [HttpGet]
        [ActionName("GetReportNetFigure")]
        public IActionResult GetReportNetFigure()
        {
            var res = _iPaymentMasterService.GetReportNetFigure();
            if (res.IsSuccess)
            {
                return Ok(res);
            }
            return NotFound(res);
        }

        [HttpGet]
        [ActionName("GetChartOrderStatus")]
        public IActionResult GetChartOrderStatus()
        {
            var res = _iPaymentMasterService.GetChartOrderStatus();
            if (res.IsSuccess)
            {
                return Ok(res);
            }
            return NotFound(res);
        }

        [HttpGet]
        [ActionName("GetChartSalesDataPaymentTypeWise")]
        public IActionResult ChartSalesDataPaymentTypeWise()
        {
            var res = _iPaymentMasterService.GetChartSalesDataPaymentTypeWise();
            if (res.IsSuccess)
            {
                return Ok(res);
            }
            return NotFound(res);
        }

        [HttpGet]
        [ActionName("GetChartUserGrowth")]
        public IActionResult ChartUserGrowth()
        {
            var res = _iPaymentMasterService.GetChartUserGrowth();
            if (res.IsSuccess)
            {
                return Ok(res);
            }
            return NotFound(res);
        }

        [HttpPost]
        [ActionName("Save")]
        public IActionResult Post([FromBody]PaymentMasterRequest viewModel)
        {
            BillingDetailsRequest Obj = new BillingDetailsRequest
            {
                firstname = viewModel.firstname,
                lastname = viewModel.lastname,
                phone = viewModel.phone,
                email = viewModel.email,
                address = viewModel.address,
                country = viewModel.country,
                town = viewModel.town,
                state = viewModel.state,
                postalcode = viewModel.postalcode,
            };
            var resBillingDetails = _iPaymentMasterService.AddBillingDetails(Obj);

            foreach (var item in viewModel.items)
            {
                PurchaseItemRequest vm = new PurchaseItemRequest
                {
                    ProductId = item.ProductId,
                    Quantity = item.Quantity,
                    Size = item.Size,
                    Color = item.Color,
                    Price = item.Price,
                    Discount = item.Discount
                };
                var resPurchaseItem = _iPaymentMasterService.AddPurchaseItem(vm);

                BillMasterRequest bm = new BillMasterRequest
                {
                    BillingDetailsId = resBillingDetails.Data.id,
                    PurchaseId = resPurchaseItem.Data.Id
                };
                var resBillMaster = _iPaymentMasterService.AddBillMaster(bm);
            }

            DoPaymentMasterRequest bp = new DoPaymentMasterRequest
            {
                BillDetailId = resBillingDetails.Data.id,
                SubTotalAmount = viewModel.amount,
                ShippingAmount = viewModel.shippingAmount,
                PaymentTypeId = Convert.ToInt16(viewModel.paymentTypeId),
                PaymentStatus = 1
            };
            var res = _iPaymentMasterService.AddPaymentMaster(bp);

            
            //added for payment
            StripePaymentRequest pay = new StripePaymentRequest
            {
                tokenId = viewModel.payment.tokenId,
                amount = viewModel.payment.amount,
                description = viewModel.payment.description
            };

            // StripeConfiguration.SetApiKey("sk_test_5m82z6BPNtU3TDAj1sDM4O6Z00vLeM0E8J");

            StripeConfiguration.ApiKey = "sk_test_5m82z6BPNtU3TDAj1sDM4O6Z00vLeM0E8J"; // Secret key

            var myCharge = new ChargeCreateOptions();
            myCharge.Source = pay.tokenId;
            myCharge.Amount = pay.amount * 100;
            myCharge.Currency = "inr";
            myCharge.Description = pay.description;
            myCharge.Metadata = new Dictionary<string, string>();
            myCharge.Metadata["OurRef"] = "OurRef-" + Guid.NewGuid().ToString();

            var chargeService = new ChargeService();
            Charge stripeCharge = chargeService.Create(myCharge);

            OnlinePaymentMasterRequest op = new OnlinePaymentMasterRequest
            {
                PaymentId = res.Data.Id,
                tokenId = pay.tokenId,
                transactionId = stripeCharge.BalanceTransactionId,
                country = stripeCharge.PaymentMethodDetails.Card.Country,
                brand = stripeCharge.PaymentMethodDetails.Card.Brand,
                exp_month = stripeCharge.PaymentMethodDetails.Card.ExpMonth,
                exp_year = stripeCharge.PaymentMethodDetails.Card.ExpYear,
                cvc_check = stripeCharge.PaymentMethodDetails.Card.Checks.CvcCheck,
                Email = stripeCharge.BillingDetails.Name,
                status = stripeCharge.Status,
                description = pay.description,
                amount = pay.amount,
            };
            var resOnlinePayment = _iPaymentMasterService.SaveOnlinePayment(op);

            return Ok(res);
        }
    }
}