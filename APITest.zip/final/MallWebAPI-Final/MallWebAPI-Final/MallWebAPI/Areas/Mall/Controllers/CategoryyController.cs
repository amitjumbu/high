﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessService.Interface;
using MallWebAPI.Filter;
using Microsoft.AspNetCore.Mvc;

namespace API.Areas.Mall.Controllers
{
    [ServiceFilter(typeof(DblExceptionFilter))]
    [Area("Mall")]
    [Produces("application/json")]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CategoryyController : ControllerBase
    {
        private readonly ICategoryService _iCategoryService;

        public CategoryyController(ICategoryService iCategoryService)
        {
            _iCategoryService = iCategoryService;
        }

        [HttpGet]
        [ActionName("GetCategoryList")]
        public IActionResult GetProductList()
        {
            var res = _iCategoryService.GetCategoryList();
            return Ok(res);
        }

        
        [HttpPost]
        [ActionName("Save")]
        public IActionResult Post([FromBody] CategoryListRequest viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState.Values.ToArray());
            }

            var res = _iCategoryService.Add(viewModel);
            return Ok(res);
        }

        [HttpPut]
        [ActionName("Update")]
        public IActionResult Update([FromBody] CategoryListRequest viewModel)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState.Values.ToArray());
            }
            var res = _iCategoryService.Update(viewModel);
            return Ok(res);
        }

        //[HttpGet("{Id}")]
        //[ActionName("GetbyId")]
        //public IActionResult GetbyId(int Id)
        //{
        //    var res = _iCustomerMasterService.GetbyId(Id);
        //    if (res.IsSuccess)
        //    {
        //        return Ok(res);
        //    }
        //    return NotFound(res);
        //}        

        //[HttpPost]
        //[ActionName("Delete")]
        //public IActionResult Delete(Value model)
        //{
        //    var res = _iCustomerMasterService.Delete(model.Id);
        //    return Ok(res);
        //}
    }
}