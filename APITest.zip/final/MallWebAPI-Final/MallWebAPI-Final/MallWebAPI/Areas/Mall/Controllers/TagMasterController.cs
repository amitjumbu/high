﻿using BusinessEntities.Mall.Master.RequestDto;
using BusinessService.Interface;
using MallWebAPI.Filter;
using Microsoft.AspNetCore.Mvc;

namespace MallWebAPI.Areas.Mall.Controllers
{
    [ServiceFilter(typeof(DblExceptionFilter))]
    [Area("Mall")]
    [Produces("application/json")]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class TagMasterController : ControllerBase
    {
        private readonly ITagMasterService _iTagMasterService;

        public TagMasterController(ITagMasterService iTagMasterService)
        {
            _iTagMasterService = iTagMasterService;
        }

        [HttpGet]
        [ActionName("GetAll")]
        public IActionResult GetAll()
        {
            var res = _iTagMasterService.GetAll();
            return Ok(res);
        }


        [HttpGet("{Id}")]
        [ActionName("GetbyId")]
        public IActionResult GetbyId(long Id)
        {
            var res = _iTagMasterService.GetById(Id);
            return Ok(res);
        }

        [HttpPost]
        [ActionName("Save")]
        public IActionResult Post([FromBody] TagMasterRequest viewModel)
        {
            var res = _iTagMasterService.Add(viewModel);
            return Ok(res);
        }

        [HttpPost]
        [ActionName("Update")]
        public IActionResult Update([FromBody] TagMasterRequest viewModel)
        {
            var res = _iTagMasterService.Update(viewModel);
            return Ok(res);
        }

        [HttpPost]
        [ActionName("Delete")]
        public IActionResult Delete(Value model)
        {
            var res = _iTagMasterService.Delete(model.Id);
            return Ok(res);
        }

    }
}