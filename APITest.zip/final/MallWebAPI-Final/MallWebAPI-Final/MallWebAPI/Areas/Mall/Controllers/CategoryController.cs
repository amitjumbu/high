﻿using System;
using System.IO;
using System.Net.Http.Headers;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessService.Interface;
using MallWebAPI.Filter;
using Microsoft.AspNetCore.Mvc;

namespace API.Areas.Mall.Controllers
{
    [ServiceFilter(typeof(DblExceptionFilter))]
    [Area("Mall")]
    [Produces("application/json")]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CategoryController : ControllerBase
    {
        private readonly ICategoryMasterService _iCategoryMasterService;

        public CategoryController(ICategoryMasterService iCategoryMasterService)
        {
            _iCategoryMasterService = iCategoryMasterService;
        }

        [HttpGet]
        [ActionName("GetAll")]
        public IActionResult GetAll()
        {
            var res = _iCategoryMasterService.GetAll();
            if (res.IsSuccess)
            {
                return Ok(res);
            }
            return NotFound(res);
        }

        [HttpGet("{Id}")]
        [ActionName("GetbyId")]
        public IActionResult GetbyId(int Id)
        {
            var res = _iCategoryMasterService.GetbyId(Id);
            if (res.IsSuccess)
            {
                return Ok(res);
            }
            return NotFound(res);
        }

        [HttpPost]
        [ActionName("Save")]
        public IActionResult UploadImage()
        {
            var postedFile = Request.Form.Files["Image"];
            //var folderName = Path.Combine("Resources", "Images");
            var folderName = "Images";
            var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);

            if (postedFile.Length > 0)
            {
                var fileName = ContentDispositionHeaderValue.Parse(postedFile.ContentDisposition).FileName.Trim('"');
                var fullPath = Path.Combine(pathToSave, fileName);
                var dbPath = Path.Combine(folderName, fileName);

                using (var stream = new FileStream(fullPath, FileMode.Create))
                {
                    postedFile.CopyTo(stream);
                }
                CategoryMasterRequest viewModel = new CategoryMasterRequest
                {
                    Name = Request.Form["Name"][0],
                    Title = Request.Form["Title"][0],
                    IsSave = Convert.ToInt16(Request.Form["IsSave"][0]),
                    Link = Request.Form["link"][0],
                    ImagePath = fileName
                };
                var res = _iCategoryMasterService.Add(viewModel);
                return Ok(res);
            }
            else
            {
                return BadRequest();
            }
        }

        [HttpPost]
        [ActionName("Update")]
        public IActionResult Update()
        {
            var postedFile = Request.Form.Files["Image"];
            //var folderName = Path.Combine("Resources", "Images");
            var folderName = "Images";
            var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);
            var fileName = "";
            if (postedFile != null && postedFile.Length > 0)
            {
                fileName = ContentDispositionHeaderValue.Parse(postedFile.ContentDisposition).FileName.Trim('"');
                var fullPath = Path.Combine(pathToSave, fileName);
                var dbPath = Path.Combine(folderName, fileName);

                using (var stream = new FileStream(fullPath, FileMode.Create))
                {
                    postedFile.CopyTo(stream);
                }
            }
            CategoryMasterRequest viewModel = new CategoryMasterRequest
            {
                Id = Convert.ToInt16(Request.Form["Id"][0]),
                Name = Request.Form["Name"][0],
                Title = Request.Form["Title"][0],
                IsSave = Convert.ToInt16(Request.Form["IsSave"][0]),
                Link = Request.Form["link"][0],
                ImagePath = fileName
            };
            var res = _iCategoryMasterService.Update(viewModel);
            return Ok(res);
        }

        [HttpPost]
        [ActionName("Delete")]
        public IActionResult Delete([FromBody]Value viewModel)
        {
            var res = _iCategoryMasterService.Delete(viewModel.Id);
            return Ok(res);
        }
    }
}