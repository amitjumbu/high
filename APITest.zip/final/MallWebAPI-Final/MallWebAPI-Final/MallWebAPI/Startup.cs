﻿using AutoMapper;
using BusinessService.Implementation;
using BusinessService.Interface;
using MallWebAPI.Extension;
using MallWebAPI.Filter;
using MallWebAPI.Helpers;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.IdentityModel.Tokens;
using Repositories.dbContext;
using Repositories.Implementation;
using Repositories.Interface;
using System.IO;
using System.Text;

namespace MallWebAPI
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
       
        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc();
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder.AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials()
                    );
            });

            //get connection string
            var connection = Configuration.GetConnectionString("SqlConnectionString");
            services.AddDbContext<AppliactionDbContext>(options => options.UseSqlServer(connection));
            //add extrension services
            ServicesConfig.AddExtensionServices(services);
            services.AddAutoMapper();

            //configure AppSettings
            var appSettingsSection = Configuration.GetSection("AppSettings");
            services.Configure<AppSettings>(appSettingsSection);

            // configure jwt authentication
            var appSettings = appSettingsSection.Get<AppSettings>();
            var key = Encoding.ASCII.GetBytes(appSettings.Secret);
            services.AddAuthentication(x =>
            {
                x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(x =>
            {
                x.RequireHttpsMetadata = false;
                x.SaveToken = true;
                x.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = false,
                    ValidateAudience = false
                };
            });


            //Repository registrated region
            services.AddScoped(typeof(ICategoryRepository), typeof(CategoryRepository));
            services.AddScoped(typeof(ISizeMasterRepository), typeof(SizeMasterRepository));
            services.AddScoped(typeof(ITagMasterRepository), typeof(TagMasterRepository));
            services.AddScoped(typeof(IColorMasterRepository), typeof(ColorMasterRepository));
            services.AddScoped(typeof(IExceptionLogRepository), typeof(ExceptionLogRepository));
            services.AddScoped(typeof(IUserMasterRepository), typeof(UserMasterRepository));
            services.AddScoped(typeof(IBrandLogoRepository), typeof(BrandLogoRepository));
            services.AddScoped(typeof(ICategoryMasterRepository), typeof(CategoryMasterRepository));
            services.AddScoped(typeof(IUserTypeRepository), typeof(UserTypeRepository));
            services.AddScoped(typeof(IContactUsRepository), typeof(ContactUsRepository));
            services.AddScoped(typeof(ICustomerMasterRepository), typeof(CustomerMasterRepository));
            services.AddScoped(typeof(IProductMasterRepository), typeof(ProductMasterRepository));
            services.AddScoped(typeof(IPaymentMasterRepository), typeof(PaymentMasterRepository));

            //Serices registred region
            services.AddScoped(typeof(ICategoryService), typeof(CategoryService));
            services.AddScoped(typeof(ISizeMasterService),typeof(SizeMasterService));
            services.AddScoped(typeof(ITagMasterService), typeof(TagMasterService));
            services.AddScoped(typeof(IColorMasterService), typeof(ColorMasterService));
            services.AddScoped(typeof(IExceptionLogService), typeof(ExceptionLogService));
            services.AddScoped(typeof(IUserMasterService), typeof(UserMasterService));
            services.AddScoped(typeof(IBrandLogoService), typeof(BrandLogoService));
            services.AddScoped(typeof(ICategoryMasterService), typeof(CategoryMasterService));
            services.AddScoped(typeof(IUserTypeService), typeof(UserTypeService));
            services.AddScoped(typeof(IContactUsService), typeof(ContactUsService));
            services.AddScoped(typeof(ICustomerMasterService), typeof(CustomerMasterService));
            services.AddScoped(typeof(IProductMasterService), typeof(ProductMasterService));
            services.AddScoped(typeof(IPaymentMasterService), typeof(PaymentMasterService));

            services.AddScoped<DblExceptionFilter>();// for Error Log

            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            ServicesConfig.AppConfigureMiddleWare(app);
            app.UseDefaultFiles();
            app.UseAuthentication();
            app.UseStaticFiles();
            app.UseFileServer();
            app.UseMvc();

            //To Save and fetch Images
            app.UseStaticFiles(new StaticFileOptions()
            {
                FileProvider = new PhysicalFileProvider(Path.Combine(Directory.GetCurrentDirectory(),@"Images")),
                RequestPath = new PathString("/Images")
            });

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                  name: "areas",
                  template: "{area:exists}/{controller=Home}/{action=Index}/{id?}"
                );

                routes.MapRoute(
                  name: "default",
                  template: "{controller=Home}/{action=Index}/{id?}"
                );
            });
        }
    }
}
