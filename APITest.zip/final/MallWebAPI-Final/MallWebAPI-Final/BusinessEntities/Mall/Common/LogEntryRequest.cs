﻿using System;

namespace BusinessEntities.Mall.Common
{
    public class LogEntryRequest
    {
        public DateTime TimeStamp { get; set; }
        public string Message { get; set; }
        public string Type { get; set; }
        public string Source { get; set; }
        public string StackTrace { get; set; }
        public string RequestPath { get; set; }
        public string Action { get; set; }
    }
}
