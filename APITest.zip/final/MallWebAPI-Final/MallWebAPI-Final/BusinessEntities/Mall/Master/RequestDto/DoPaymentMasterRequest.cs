﻿namespace BusinessEntities.Mall.Master.RequestDto
{
    public class DoPaymentMasterRequest : BaseRequest
    {
        public int Id { get; set; }
        public int? BillDetailId { get; set; }
        public string SubTotalAmount { get; set; }
        public string ShippingAmount { get; set; }
        public int PaymentTypeId { get; set; }
        public int PaymentStatus { get; set; }
    }
}
