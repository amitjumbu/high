﻿namespace BusinessEntities.Mall.Master.RequestDto
{
    public class BrandLogoRequest : BaseRequest
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ImagePath { get; set; }
    }
}
