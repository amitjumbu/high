﻿namespace BusinessEntities.Mall.Master.RequestDto
{
    public class UserTypeRequest : BaseRequest
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
