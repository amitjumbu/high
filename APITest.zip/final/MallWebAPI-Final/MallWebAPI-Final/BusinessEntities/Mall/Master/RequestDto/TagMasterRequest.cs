﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessEntities.Mall.Master.RequestDto
{
    public class TagMasterRequest : BaseRequest
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
