﻿namespace BusinessEntities.Mall.Master.RequestDto
{
    public class CategoryListRequest : BaseRequest
    {
        public int Id { get; set; }
        public string MembershipName { get; set; }
        public string CategoryType { get; set; }
        public string Description { get; set; }
    }
}
