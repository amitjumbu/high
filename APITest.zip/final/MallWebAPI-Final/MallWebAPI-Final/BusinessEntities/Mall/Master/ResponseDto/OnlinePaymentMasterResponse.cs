﻿namespace BusinessEntities.Mall.Master.ResponseDto
{
    public class OnlinePaymentMasterResponse
    {
        public int Id { get; set; }
        public int PaymentId { get; set; }
        public string tokenId { get; set; }
        public string transactionId { get; set; }
        public string country { get; set; }
        public string brand { get; set; }
        public long exp_month { get; set; }
        public long exp_year { get; set; }
        public string cvc_check { get; set; }
        public string Email { get; set; }
        public string status { get; set; }
        public string description { get; set; }
        public decimal amount { get; set; }
    }
}
