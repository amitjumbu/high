﻿namespace BusinessEntities.Mall.Master.ResponseDto
{
    public class ProductListSizesResponse
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
    }
}
