﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessEntities.Mall.Master.ResponseDto
{
    public class CategoryMasterResponse :BaseResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Title { get; set; }
        public string ImagePath { get; set; }
        public int IsSave { get; set; }
        public string Link { get; set; }
    }
}
