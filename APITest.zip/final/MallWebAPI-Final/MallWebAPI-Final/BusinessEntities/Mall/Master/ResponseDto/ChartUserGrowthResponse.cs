﻿namespace BusinessEntities.Mall.Master.ResponseDto
{
   public class ChartUserGrowthResponse
    {
        public string UserType { get; set; }
        public string Date { get; set; }
        public int counts { get; set; }
    }
}
