import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, map, catchError } from 'rxjs/Operators';

@Injectable({
  providedIn: 'root'
})
export class ResponseInterceptors implements HttpInterceptor {

  constructor() { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    debugger;
    return next.handle(req).pipe(
      retry(3),
      map(resp => {
        if (resp instanceof HttpResponse) {
          console.log("Response is : ");
          console.log(resp.body);
        }
        return resp;
      }),
      catchError((error: HttpErrorResponse) => {
        let errMsg = '';
        //Client-side error
        if (error.error instanceof ErrorEvent) {
          errMsg = `Error : ${error.error.message}`;
          //Redirect to Error page
        } else { //Server-side error
          errMsg = `Error Code : ${error.status}, Message : ${error.message}`;
          //Redirect to Error page
        }
        return throwError(errMsg);
      })
    )


  }


}
