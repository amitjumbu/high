import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';
import { DataService } from 'src/app/shared/services/data.service';
import { ToastrService } from 'ngx-toastr';
import { MustMatchValidator } from 'src/app/Validators/validations.validator';
import { Global } from 'src/app/shared/global';
import { NgbTabChangeEvent } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  registrationFrom: FormGroup;
  submitted: boolean = false;
  strMsg: string;

  @ViewChild('tabset') elname: any;

  constructor(private _authService: AuthService, private _dataService: DataService, private _fb: FormBuilder, private _toastr: ToastrService) {
    this.strMsg = "";
    this._authService.logout();
  }

  ngOnInit(): void {
    this.createLoginForm();
    this.createRegistrationForm();
  }

  createLoginForm() {
    this.loginForm = this._fb.group({
      userName: [''],
      password: ['']
    });
  }

  createRegistrationForm() {
    this.registrationFrom = this._fb.group({
      Id: [0],
      FirstName: ['', Validators.required],
      LastName: ['', Validators.required],
      Email: ['', [Validators.required, Validators.email]],
      UserTypeId: [0],
      Password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
    },
      {
        validator: MustMatchValidator('Password', 'confirmPassword')
      }

    );
  }

  get f() {
    return this.registrationFrom.controls;
  }

  onLoginSubmit() {
    if (this.loginForm.valid) {
      this._dataService.post(Global.BASE_USER_ENDPOINT + "UserMaster/login/", this.loginForm.value).subscribe(res => {
        if (res.isSuccess) {
          this._authService.login(res.data);
          this.strMsg = this._authService.getMessage();
          if (this.strMsg != "") {
            this._toastr.error(this.strMsg, "Login");
            this.reset();
          }
        } else {
          this._toastr.error("Login failed !!", "Login");
          this.reset();
        }
      });
    }
  }

  onRegistration(formdata: any) {
    this.submitted = true;
    if (this.registrationFrom.invalid) {
      return;
    }

    //this.registrationFrom.controls['Id'].setValue(0);

    this._dataService.post(Global.BASE_USER_ENDPOINT + "UserMaster/Save/", formdata.value).subscribe(res => {
      if (res.isSuccess) {
        this._toastr.success("Account has been created successfully !!", "User Master");
        this.registrationFrom.reset();
        this.elname.select('logintab');
      } else {
        this._toastr.info(res.errors[0], "User Master");
      }
    });

  }

  reset() {
    this.loginForm.controls['userName'].setValue('');
    this.loginForm.controls['password'].setValue('');
  }

  beforeChange(event: NgbTabChangeEvent) {
    // if (event.nextId === 'registrationtab') {
    //   event.preventDefault();
    // }
  }

}
