import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usertype',
  templateUrl: './usertype.component.html',
  styleUrls: ['./usertype.component.scss']
})
export class UsertypeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
