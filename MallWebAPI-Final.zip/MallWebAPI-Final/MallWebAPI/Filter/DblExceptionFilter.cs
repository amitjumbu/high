﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using BusinessService.Interface;
using BusinessEntities.Mall.Common;

namespace MallWebAPI.Filter
{
    public class DblExceptionFilter : ExceptionFilterAttribute
    {
        private readonly IExceptionLogService _iExceptionLogService;
        private readonly IHostingEnvironment _iHostingEnvironment;

        public DblExceptionFilter(IExceptionLogService iExceptionLogService, IHostingEnvironment iHostingEnvironment)
        {
            _iExceptionLogService = iExceptionLogService;
            _iHostingEnvironment = iHostingEnvironment;
        }



        public override void OnException(ExceptionContext context)
        {
            if (_iHostingEnvironment.IsDevelopment())
            {
                LogEntryRequest log = new LogEntryRequest
                {
                    TimeStamp = DateTime.Now,
                    Action = context.ActionDescriptor.DisplayName,
                    Message = context.Exception.Message,
                    RequestPath = context.HttpContext.Request.Path,
                    Source = context.Exception.Source,
                    StackTrace = context.Exception.StackTrace,
                    Type = context.Exception.GetType().ToString()
                };

                _iExceptionLogService.Add(log);
            }
        }
    }
}
