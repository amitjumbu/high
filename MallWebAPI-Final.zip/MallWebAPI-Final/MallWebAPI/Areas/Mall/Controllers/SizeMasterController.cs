﻿using BusinessEntities.Mall.Master.RequestDto;
using BusinessService.Interface;
using MallWebAPI.Filter;
using Microsoft.AspNetCore.Mvc;

namespace MallWebAPI.Areas.Mall.Controllers
{
    [ServiceFilter(typeof(DblExceptionFilter))]
    [Area("Mall")]
    [Produces("application/json")]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class SizeMasterController : ControllerBase
    {
        private readonly ISizeMasterService _iSizeMasterService;

        public SizeMasterController(ISizeMasterService iSizeMasterService)
        {
            _iSizeMasterService = iSizeMasterService;
        }

        [HttpGet]
        [ActionName("GetAll")]
        public IActionResult GetAll()
        {
            var res = _iSizeMasterService.GetAll();
            return Ok(res);
        }


        [HttpGet("{Id}")]
        [ActionName("GetbyId")]
        public IActionResult GetbyId(long Id)
        {
            var res = _iSizeMasterService.GetById(Id);
            return Ok(res);
        }

        [HttpPost]
        [ActionName("Save")]
        public IActionResult Post([FromBody] SizeMasterRequest viewModel)
        {
            var res = _iSizeMasterService.Add(viewModel);
            return Ok(res);
        }

        [HttpPost]
        [ActionName("Update")]
        public IActionResult Update([FromBody] SizeMasterRequest viewModel)
        {
            var res = _iSizeMasterService.Update(viewModel);
            return Ok(res);
        }

        [HttpPost]
        [ActionName("Delete")]
        public IActionResult Delete(Value model )
        {
            var res = _iSizeMasterService.Delete(model.Id);
            return Ok(res);
        }

    }
}