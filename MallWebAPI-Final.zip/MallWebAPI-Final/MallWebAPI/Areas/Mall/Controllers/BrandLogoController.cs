﻿using System;
using System.IO;
using System.Net.Http.Headers;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessService.Interface;
using MallWebAPI.Filter;
using Microsoft.AspNetCore.Mvc;

namespace API.Areas.Mall.Controllers
{
    [ServiceFilter(typeof(DblExceptionFilter))]
    [Area("Mall")]
    [Produces("application/json")]
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class BrandLogoController : ControllerBase
    {
        private readonly IBrandLogoService _iBrandLogoService;

        public BrandLogoController(IBrandLogoService iBrandLogoService)
        {
            _iBrandLogoService = iBrandLogoService;
        }

        [HttpGet]
        [ActionName("GetAll")]
        public IActionResult GetAll()
        {
            var res = _iBrandLogoService.GetAll();
            if (res.IsSuccess)
            {
                return Ok(res);
            }
            return NotFound(res);
        }

        [HttpGet("{Id}")]
        [ActionName("GetbyId")]
        public IActionResult GetbyId(int Id)
        {
            var res = _iBrandLogoService.GetbyId(Id);
            if (res.IsSuccess)
            {
                return Ok(res);
            }
            return NotFound(res);
        }

        [HttpPost]
        [ActionName("Save")]
        public IActionResult UploadImage()
        {
            var Name = Request.Form["Name"][0];
            var postedFile = Request.Form.Files["Image"];
            var folderName = "Images";
            var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);

            if (postedFile.Length > 0)
            {
                var fileName = ContentDispositionHeaderValue.Parse(postedFile.ContentDisposition).FileName.Trim('"');
                var fullPath = Path.Combine(pathToSave, fileName);

                using (var stream = new FileStream(fullPath, FileMode.Create))
                {
                    postedFile.CopyTo(stream);
                }

                BrandLogoRequest viewModel = new BrandLogoRequest
                {
                    Name = Name,
                    ImagePath = fileName
                };
                var res = _iBrandLogoService.Add(viewModel);
                return Ok(res);
            }
            else
            {
                return BadRequest();
            }
        }

        [HttpPost]
        [ActionName("Update")]
        public IActionResult Update()
        {
            var Id = Request.Form["Id"][0] ?? "0";
            var Name = Request.Form["Name"][0];
            var postedFile = Request.Form.Files["Image"];
            var folderName = "Images";
            var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);
            var fileName = "";
            if (postedFile != null && postedFile.Length > 0)
            {
                fileName = ContentDispositionHeaderValue.Parse(postedFile.ContentDisposition).FileName.Trim('"');
                var fullPath = Path.Combine(pathToSave, fileName);
                var dbPath = Path.Combine(folderName, fileName);

                using (var stream = new FileStream(fullPath, FileMode.Create))
                {
                    postedFile.CopyTo(stream);
                }
            }
            BrandLogoRequest viewModel = new BrandLogoRequest
            {
                Id = Convert.ToInt16(Id),
                Name = Name,
                ImagePath = fileName
            };
            var res = _iBrandLogoService.Update(viewModel);
            return Ok(res);
        }

        [HttpPost]
        [ActionName("Delete")]
        public IActionResult Delete([FromBody]Value viewModel)
        {
            var res = _iBrandLogoService.Delete(viewModel.Id);
            return Ok(res);
        }
    }
}