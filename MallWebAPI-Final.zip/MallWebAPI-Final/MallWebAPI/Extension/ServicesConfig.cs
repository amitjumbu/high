﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

namespace MallWebAPI.Extension
{
    public static class ServicesConfig
    {

        public static void AddExtensionServices(this IServiceCollection services)
        {
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Swashbuckle.AspNetCore.Swagger.Info
                {
                    Version = "V1",
                    Title = "Mall Api",
                    Description = "Live Project Training",
                    TermsOfService = "......",
                    Contact = new Swashbuckle.AspNetCore.Swagger.Contact()
                    {
                        Name = "Sahosoft",
                        Email = "Ajeetsingha@gmail.com",
                        Url = "sahosoft.com"
                    }

                });
            });
        }

        public static void AppConfigureMiddleWare(this IApplicationBuilder app)
        {
            app.UseCors("CorsPolicy");
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.RoutePrefix = "swagger";
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "swagger api");
            });
        }
    }
}
