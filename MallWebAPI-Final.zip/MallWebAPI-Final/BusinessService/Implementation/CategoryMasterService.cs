﻿using AutoMapper;
using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.Master.ResponseDto;
using BusinessService.Interface;
using Repositories.Interface;
using Repositories.Mall;
using System.Collections.Generic;

namespace BusinessService.Implementation
{
   public class CategoryMasterService : ICategoryMasterService
    {
        private readonly ICategoryMasterRepository _iCategoryMasterRepository;
        private IMapper _mapper;
        public CategoryMasterService(IMapper mapper, ICategoryMasterRepository repository)
        {
            _iCategoryMasterRepository = repository;
            _mapper = mapper;
        }

        public ResultDto<long> Add(CategoryMasterRequest viewModel)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iCategoryMasterRepository.Add(viewModel);
            if (response == -1)
            {
                res.Errors.Add("Category name allready exists");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = response;
                return res;
            }
        }
        public ResultDto<long> Update(CategoryMasterRequest viewModel)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iCategoryMasterRepository.Update(viewModel);
            if (response == -1)
            {
                res.Errors.Add("Category name not exists");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = response;
                return res;
            }
        }
        public ResultDto<long> Delete(int ID)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iCategoryMasterRepository.Delete(ID);
            if (response == -1)
            {
                res.Errors.Add("Category name not exists");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = response;
                return res;
            }
        }
        public ResultDto<CategoryMasterResponse> GetbyId(int Id)
        {
            var res = new ResultDto<CategoryMasterResponse>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iCategoryMasterRepository.GetbyId(Id);
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<DBCategoryMaster, CategoryMasterResponse>(response);
                return res;
            }
        }
        public ResultDto<IEnumerable<CategoryMasterResponse>> GetAll()
        {
            var res = new ResultDto<IEnumerable<CategoryMasterResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iCategoryMasterRepository.GetAll();
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBCategoryMaster>, IEnumerable<CategoryMasterResponse>>(response);
                return res;
            }
        }
    }
}
