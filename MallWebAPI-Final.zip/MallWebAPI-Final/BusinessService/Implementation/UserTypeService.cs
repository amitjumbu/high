﻿using AutoMapper;
using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.Master.ResponseDto;
using BusinessService.Interface;
using Repositories.Interface;
using Repositories.Mall;
using System.Collections.Generic;

namespace BusinessService.Implementation
{
    public class UserTypeService : IUserTypeService
    {
        private readonly IUserTypeRepository _iUserTypeRepository;
        private IMapper _mapper;
        public UserTypeService(IMapper mapper, IUserTypeRepository repository)
        {
            _iUserTypeRepository = repository;
            _mapper = mapper;
        }

        public ResultDto<long> Add(UserTypeRequest viewModel)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iUserTypeRepository.Add(viewModel);
            if (response == -1)
            {
                res.Errors.Add("User type allready exists");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = response;
                return res;
            }
        }
        public ResultDto<long> Update(UserTypeRequest viewModel)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iUserTypeRepository.Update(viewModel);
            if (response == -1)
            {
                res.Errors.Add("User type not exists");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = response;
                return res;
            }
        }
        public ResultDto<long> Delete(int ID)
        {
            var res = new ResultDto<long>()
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iUserTypeRepository.Delete(ID);
            if (response == -1)
            {
                res.Errors.Add("User type not exists");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = response;
                return res;
            }
        }
        public ResultDto<UserTypeResponse> GetbyId(int Id)
        {
            var res = new ResultDto<UserTypeResponse>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iUserTypeRepository.GetbyId(Id);
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<DBUserType, UserTypeResponse>(response);
                return res;
            }
        }
        public ResultDto<IEnumerable<UserTypeResponse>> GetAll()
        {
            var res = new ResultDto<IEnumerable<UserTypeResponse>>()
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iUserTypeRepository.GetAll();
            if (response == null)
            {
                res.Errors.Add("An Error Occured");
                return res;
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBUserType>, IEnumerable<UserTypeResponse>>(response);
                return res;
            }
        }
    }
}
