﻿using AutoMapper;
using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.Master.ResponseDto;
using BusinessService.Interface;
using Repositories.Interface;
using Repositories.Mall;
using System.Collections.Generic;

namespace BusinessService.Implementation
{
    public class SizeMasterService : ISizeMasterService
    {
        private readonly ISizeMasterRepository _iSizeMasterRepository;
        private IMapper _mapper;
        public SizeMasterService(IMapper mapper, ISizeMasterRepository repository)
        {
            _mapper = mapper;
            _iSizeMasterRepository = repository;
        }

        public ResultDto<long> Add(SizeMasterRequest viewModel)
        {
            var res = new ResultDto<long>
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };

            var response = _iSizeMasterRepository.Add(viewModel);
            if (response>0)
            {
                res.IsSuccess = true;
                res.Data = response;
            }
            else
            {
                res.Errors.Add("Size name already exists !!");
            }

            return res;
        }
        public ResultDto<long> Update(SizeMasterRequest viewModel)
        {
            var res = new ResultDto<long>
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iSizeMasterRepository.Update(viewModel);
            if (response > 0)
            {
                res.IsSuccess = true;
                res.Data = response;
            }
            else
            {
                res.Errors.Add("Size name already exists !!");
            }
            return res;
        }
        public ResultDto<long> Delete(long Id)
        {
            var res = new ResultDto<long>
            {
                IsSuccess = false,
                Data = 0,
                Errors = new List<string>()
            };
            var response = _iSizeMasterRepository.Delete(Id);
            if (response > 0)
            {
                res.IsSuccess = true;
                res.Data = response;
            }
            else
            {
                res.Errors.Add("Record not found !!");
            }
            return res;
        }

        public ResultDto<SizeMasterResponse> GetById(long Id)
        {
            var res = new ResultDto<SizeMasterResponse>
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };

            //Mapper.Initialize(config =>
            //{
            //    config.CreateMap<DBSizeMaster, SizeMasterResponse>()
            //    .ForMember(dest => dest.Email, act => act.Ignore())
            //     .ForMember(dest => dest.Mobile, act => act.Ignore())
            //     .ForMember(dest => dest.FullName, map => map.MapFrom(m => m.Name + " ( " + m.Id + ")"));
            //});


            var response = _iSizeMasterRepository.GetById(Id);

            if (response==null)
            {
                res.Errors.Add("No Record Found !!");
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<DBSizeMaster, SizeMasterResponse>(response);
               // res.Data = Mapper.Map<DBSizeMaster, SizeMasterResponse>(response);
            }
            return res;
        }

        public ResultDto<IEnumerable<SizeMasterResponse>> GetAll()
        {
            var res = new ResultDto<IEnumerable<SizeMasterResponse>>
            {
                IsSuccess = false,
                Data = null,
                Errors = new List<string>()
            };
            var response = _iSizeMasterRepository.GetAll();

            if (response == null)
            {
                res.Errors.Add("No Record Found !!");
            }
            else
            {
                res.IsSuccess = true;
                res.Data = _mapper.Map<IEnumerable<DBSizeMaster>, IEnumerable<SizeMasterResponse>>(response);
            }
            return res;
        }
    }
}
