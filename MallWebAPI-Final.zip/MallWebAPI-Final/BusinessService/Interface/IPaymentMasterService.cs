﻿using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.Master.ResponseDto;
using System.Collections.Generic;

namespace BusinessService.Interface
{
    public interface IPaymentMasterService
    {
        ResultDto<BillingDetailsResponse> AddBillingDetails(BillingDetailsRequest viewModel);
        ResultDto<PurchaseItemResponse> AddPurchaseItem(PurchaseItemRequest viewModel);
        ResultDto<long> AddBillMaster(BillMasterRequest viewModel);
        ResultDto<DoPaymentMasterResponse> AddPaymentMaster(DoPaymentMasterRequest viewModel);
        ResultDto<OnlinePaymentMasterResponse> SaveOnlinePayment(OnlinePaymentMasterRequest viewModel);
        //Report Section Here
        ResultDto<IEnumerable<ReportManageOrderResponse>> GetReportManageOrder();
        ResultDto<IEnumerable<ReportTransactionDetailsResponse>> GetReportTransactionDetails();
        ResultDto<IEnumerable<ReportManageOrderResponse>> GetReportCashOnDelivery();
        ResultDto<IEnumerable<ReportManageOrderResponse>> GetReportInvoiceList();
        ResultDto<IEnumerable<ReportNetFigureResponse>> GetReportNetFigure();
        //Chart Section Here
        ResultDto<IEnumerable<ChartOrderStatusResponse>> GetChartOrderStatus();
        ResultDto<IEnumerable<ChartSalesDataPaymentTypeWiseResponse>> GetChartSalesDataPaymentTypeWise();
        ResultDto<IEnumerable<ChartUserGrowthResponse>> GetChartUserGrowth();
    }
}
