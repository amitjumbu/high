﻿using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.Master.ResponseDto;
using System.Collections.Generic;

namespace BusinessService.Interface
{
    public interface IColorMasterService
    {
        ResultDto<long> Add(ColorMasterRequest viewModel);
        ResultDto<long> Update(ColorMasterRequest viewModel);
        ResultDto<long> Delete(long Id);
        ResultDto<ColorMasterResponse> GetById(long Id);
        ResultDto<IEnumerable<ColorMasterResponse>> GetAll();
    }
}
