﻿using BusinessEntities.Mall.Common;
using BusinessEntities.Mall.Master.RequestDto;
using BusinessEntities.Mall.Master.ResponseDto;
using System.Collections.Generic;

namespace BusinessService.Interface
{
    public interface ISizeMasterService
    {
        ResultDto<long> Add(SizeMasterRequest viewModel);
        ResultDto<long> Update(SizeMasterRequest viewModel);
        ResultDto<long> Delete(long Id);
        ResultDto<SizeMasterResponse> GetById(long Id);
        ResultDto<IEnumerable<SizeMasterResponse>> GetAll();
    }
}
