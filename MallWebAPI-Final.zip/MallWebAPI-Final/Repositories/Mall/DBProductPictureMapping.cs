﻿namespace Repositories.Mall
{
    public class DBProductPictureMapping:BaseEntity
    {
        public int Id { get; set; }
        public string ProductId { get; set; }
        public string PictureName { get; set; }
        public string PicturePath { get; set; }
    }
}
