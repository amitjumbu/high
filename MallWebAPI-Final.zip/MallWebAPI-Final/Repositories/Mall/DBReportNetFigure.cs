﻿namespace Repositories.Mall
{
    public class DBReportNetFigure
    {
        public decimal Orders { get; set; }
        public decimal ShippingAmount { get; set; }
        public decimal CashOnDelivery { get; set; }
        public decimal Cancelled { get; set; }
    }
}
