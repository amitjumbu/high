﻿namespace Repositories.Mall
{
    public class DBProductListVariants
    {
        public int ProductId { get; set; }
        public string color { get; set; }
        public string images { get; set; }
    }
}
