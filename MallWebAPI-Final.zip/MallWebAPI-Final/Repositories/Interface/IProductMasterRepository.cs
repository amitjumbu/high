﻿using BusinessEntities.Mall.Master.RequestDto;
using Repositories.Mall;
using System.Collections.Generic;

namespace Repositories.Interface
{
    public interface IProductMasterRepository
    {
        DBProductMaster Add(ProductMasterRequest viewModel);
        DBProductMaster Update(ProductMasterRequest viewModel);
        long Delete(int ID);
        DBProductMaster GetbyId(int TypeId);
        IEnumerable<DBProductListPictures> GetProductPicturebyId(int Id);
        IEnumerable<DBProductMaster> GetAll();
        long AddImageMapping(ProductPictureMappingRequest viewModel);

        //for forntend data
        IEnumerable<DBProductList> GetProductList();
        IEnumerable<DBProductListColors> GetProductcolorsList();
        IEnumerable<DBProductListPictures> GetProductPicturesList();
        IEnumerable<DBProductListSizes> GetProductSizesList();
        IEnumerable<DBProductListTags> GetProductTagsList();
        IEnumerable<DBProductListVariants> GetProductVariantsList();
    }
}
