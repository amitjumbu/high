﻿using BusinessEntities.Mall.Common;

namespace Repositories.Interface
{
    public interface IExceptionLogRepository
    {
        long Add(LogEntryRequest viewModel);
    }
}
