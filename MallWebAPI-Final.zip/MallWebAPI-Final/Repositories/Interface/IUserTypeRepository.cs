﻿using BusinessEntities.Mall.Master.RequestDto;
using Repositories.Mall;
using System.Collections.Generic;

namespace Repositories.Interface
{
    public interface IUserTypeRepository
    {
        long Add(UserTypeRequest viewModel);
        long Update(UserTypeRequest viewModel);
        long Delete(int ID);
        DBUserType GetbyId(int TypeId);
        IEnumerable<DBUserType> GetAll();
    }
}
