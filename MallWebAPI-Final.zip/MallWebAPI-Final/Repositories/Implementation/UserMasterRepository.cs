﻿using Repositories.Mall;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System;
using BusinessEntities.Mall.Master.RequestDto;
using Repositories.dbContext;
using Repositories.Interface;

namespace Repositories.Implementation
{
    public class UserMasterRepository : IUserMasterRepository
    {
        protected AppliactionDbContext _Context;
        public UserMasterRepository(AppliactionDbContext context) 
        {
            _Context = context;
        }
       
        public long Add(UserMasterRequest viewModel)
        {
                var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE  InsertUserMaster @FirstName,@LastName,@Email,@Password,@UserTypeId,@CreatedBy",
                     new SqlParameter("@FirstName", viewModel.FirstName),
                     new SqlParameter("@LastName", viewModel.LastName),
                     new SqlParameter("@Email", viewModel.Email),
                     new SqlParameter("@Password", viewModel.Password),
                     new SqlParameter("@UserTypeId", viewModel.UserTypeId),
                     new SqlParameter("@CreatedBy", viewModel.CreatedBy)
                 );
                return lst;
        }
        public long UpdateUser(UserMasterRequest viewModel)
        {
                var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE  UpdateUserMaster @UserId,@FirstName,@LastName,@Email,@Password,@UserTypeId,@ModifiedBy,@ModifiedOn",
                     new SqlParameter("@UserId", viewModel.Id),
                     new SqlParameter("@FirstName", viewModel.FirstName),
                     new SqlParameter("@LastName", viewModel.LastName),
                     new SqlParameter("@Email", viewModel.Email),
                     new SqlParameter("@Password", viewModel.Password),
                     new SqlParameter("@UserTypeId", viewModel.UserTypeId),
                     new SqlParameter("@ModifiedBy", viewModel.ModifiedBy),
                     new SqlParameter("@ModifiedOn", Convert.ToDateTime(DateTime.Now.ToString()))
                 );
                return lst;
        }
        public long DeleteUser(int UserId)
        {
            var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE  DeleteUserMaster @UserId",
                    new SqlParameter("@UserId", UserId)
                );
            
            return lst;
        }
        public IEnumerable<DBUserMaster> GetAllUser()
        {
            List<DBUserMaster> lst = _Context.UserMasters.FromSql("GetAllUsers").ToList();
            return lst;
        }
        public DBUserMaster GetUserbyId(int UserId)
        {
            DBUserMaster lst = _Context.UserMasters.FromSql("GetUserbyId @UserId",
             new SqlParameter("@UserId", UserId)
             ).FirstOrDefault();
            return lst;
        }
        public DBLogin Login(LoginRequest viewModel)
        {
            DBLogin lst = _Context.Logins.FromSql("GetLogin @UserName,@Password",
             new SqlParameter("@UserName", viewModel.UserName),
             new SqlParameter("@Password", viewModel.Password)
             ).FirstOrDefault();
            return lst;
        }
    }
}
