﻿using BusinessEntities.Mall.Common;
using Microsoft.EntityFrameworkCore;
using Repositories.dbContext;
using Repositories.Interface;
using System;
using System.Data.SqlClient;

namespace Repositories.Implementation
{
    public class ExceptionLogRepository : IExceptionLogRepository
    {
        private AppliactionDbContext _Context;
        public ExceptionLogRepository(AppliactionDbContext context)
        {
            _Context = context;
        }

        public long Add(LogEntryRequest viewModel)
        {
            try
            {
                var obj = _Context.Database.ExecuteSqlCommand(" Execute InsertExceptionLog  @TimeStamp,@Message,@Type,@Source,@StackTrace,@RequestPath",
                     new SqlParameter("@TimeStamp", viewModel.TimeStamp),
                    new SqlParameter("@Message", viewModel.Message),
                    new SqlParameter("@Type", viewModel.Type),
                    new SqlParameter("@Source", viewModel.Source),
                    new SqlParameter("@StackTrace", viewModel.StackTrace),
                    new SqlParameter("@RequestPath", viewModel.RequestPath)
                    );

                return obj;
            }
            catch (Exception ex)
            {

            }
            return 0;
        }
    }
}
