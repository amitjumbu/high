﻿using BusinessEntities.Mall.Master.RequestDto;
using Microsoft.EntityFrameworkCore;
using Repositories.dbContext;
using Repositories.Interface;
using Repositories.Mall;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;

namespace Repositories.Implementation
{
    public class BrandLogoRepository : IBrandLogoRepository
    {
        protected AppliactionDbContext _Context;
        public BrandLogoRepository(AppliactionDbContext context)
        {
            _Context = context;
        }

        public long Add(BrandLogoRequest viewModel)
        {
                var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE  InsertBrandLogo @Name,@ImagePath,@CreatedBy",
                     new SqlParameter("@Name", viewModel.Name),
                     new SqlParameter("@ImagePath", viewModel.ImagePath),
                     new SqlParameter("@CreatedBy", viewModel.CreatedBy)
                 );
                return lst;
        }
        public long Update(BrandLogoRequest viewModel)
        {
                var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE  UpdateBrandLogo @Id,@Name,@ImagePath,@ModifiedBy,@ModifiedOn",
                     new SqlParameter("@Id", viewModel.Id),
                     new SqlParameter("@Name", viewModel.Name),
                     new SqlParameter("@ImagePath", viewModel.ImagePath),
                     new SqlParameter("@ModifiedBy", viewModel.ModifiedBy),
                     new SqlParameter("@ModifiedOn", viewModel.ModifiedOn)
                 );
                return lst;
        }
        public long Delete(int Id)
        {
            var lst = _Context.Database.ExecuteSqlCommand(" EXECUTE  DeleteBrandLogo @Id",
                    new SqlParameter("@Id", Id)
                );

            return lst;
        }
        public IEnumerable<DBBrandLogo> GetAll()
        {
            List<DBBrandLogo> lst = _Context.BrandLogos.FromSql("GetAllBrandLogo").ToList();
            return lst;
        }
        public DBBrandLogo GetbyId(int Id)
        {
            DBBrandLogo lst = _Context.BrandLogos.FromSql("GetBrandLogobyId @Id",
             new SqlParameter("@Id", Id)
             ).FirstOrDefault();
            return lst;
        }
    }
}
