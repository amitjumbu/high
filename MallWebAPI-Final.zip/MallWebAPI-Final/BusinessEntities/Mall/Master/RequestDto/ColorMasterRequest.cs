﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessEntities.Mall.Master.RequestDto
{
   public class ColorMasterRequest : BaseRequest
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
    }
}
