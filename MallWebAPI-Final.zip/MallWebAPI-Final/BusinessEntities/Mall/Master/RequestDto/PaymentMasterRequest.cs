﻿namespace BusinessEntities.Mall.Master.RequestDto
{
    public class PaymentMasterRequest : BaseRequest
    {
        public int id { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string phone { get; set; }
        public string email { get; set; }
        public string address { get; set; }
        public string country { get; set; }
        public string town { get; set; }
        public string state { get; set; }
        public string postalcode { get; set; }
        public string amount { get; set; }
        public string shippingAmount { get; set; }
        public string paymentTypeId { get; set; }
        public Purchaseitems[] items { get; set; }
        public StripePaymentRequest payment { get; set; }
    }
    public class Purchaseitems
    {
        public int ProductId { get; set; }
        public string Quantity { get; set; }
        public string Size { get; set; }
        public string Color { get; set; }
        public string Price { get; set; }
        public string Discount { get; set; }
    }
    public class StripePaymentRequest
    {
        public string tokenId { get; set; }
        public string description { get; set; }
        public int amount { get; set; }
    }
}
