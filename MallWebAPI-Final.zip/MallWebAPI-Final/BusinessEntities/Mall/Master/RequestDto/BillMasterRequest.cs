﻿namespace BusinessEntities.Mall.Master.RequestDto
{
    public class BillMasterRequest
    {
        public int Id { get; set; }
        public int? PurchaseId { get; set; }
        public int? BillingDetailsId { get; set; }
    }
}
