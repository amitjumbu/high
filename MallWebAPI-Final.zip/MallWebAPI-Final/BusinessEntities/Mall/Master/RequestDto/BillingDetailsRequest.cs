﻿namespace BusinessEntities.Mall.Master.RequestDto
{
    public class BillingDetailsRequest:BaseRequest
    {
        public int Id { get; set; }
        public int? customerId { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string phone { get; set; }
        public string email { get; set; }
        public string address { get; set; }
        public string country { get; set; }
        public string town { get; set; }
        public string state { get; set; }
        public string postalcode { get; set; }
    }
}
