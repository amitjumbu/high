﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessEntities.Mall.Master.ResponseDto
{
   public class ColorMasterResponse : BaseResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
    }
}
