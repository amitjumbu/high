﻿namespace BusinessEntities.Mall.Master.ResponseDto
{
    public class ProductListVariantsResponse
    {
        public int ProductId { get; set; }
        public string color { get; set; }
        public string images { get; set; }
    }
}
