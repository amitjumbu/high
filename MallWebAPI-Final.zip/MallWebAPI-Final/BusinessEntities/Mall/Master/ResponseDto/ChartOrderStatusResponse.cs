﻿namespace BusinessEntities.Mall.Master.ResponseDto
{
    public class ChartOrderStatusResponse
    {
        public string OrderStatus { get; set; }
        public string Date { get; set; }
        public int counts { get; set; }
    }
}
