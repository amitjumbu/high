﻿namespace BusinessEntities.Mall.Master.ResponseDto
{
    public class ProductListPicturesResponse
    {
        public int ProductId { get; set; }
        public string Name { get; set; }
    }
}
