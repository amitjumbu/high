﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessEntities.Mall.Master.ResponseDto
{
   public class TagMasterResponse :BaseResponse
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
