import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inventory-availability-forecast',
  templateUrl: './inventory-availability-forecast.component.html',
  styleUrls: ['./inventory-availability-forecast.component.css']
})
export class InventoryAvailabilityForecastComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
