﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using WebAPI.Data;

namespace WebAPI.Controllers
{
    [EnableCors("*","*","*")]
    public class UserController : ApiController
    {
        DatabaseContext db;
        public UserController()
        {
            db = new DatabaseContext();
        }

        //api/user
        public IEnumerable<User> GetUsers()
        {
            return db.Users.ToList();
        }

        // [HttpGet]
        //api/user/{id}
        public User GetUser(int id)
        {
            return db.Users.Find(id);
        }

        [HttpPost]
        public HttpResponseMessage AddUser(User model)
        {
            try
            {
                //db.Users.Add(model);
                db.Entry(model).State = System.Data.Entity.EntityState.Added;
                db.SaveChanges();

                HttpResponseMessage res = new HttpResponseMessage(HttpStatusCode.Created);
                return res;
            }
            catch (Exception ex)
            {
                HttpResponseMessage res = new HttpResponseMessage(HttpStatusCode.InternalServerError);
                return res;
            }
        }

        [HttpPut]
        public HttpResponseMessage UpdateUser(int id, User model)
        {
            try
            {
                db.Entry(model).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();

                HttpResponseMessage res = new HttpResponseMessage(HttpStatusCode.OK);
                return res;
            }
            catch (Exception ex)
            {
                HttpResponseMessage res = new HttpResponseMessage(HttpStatusCode.NotModified);
                return res;
            }
        }

        [HttpDelete]
        public HttpResponseMessage DeleteUser(int id)
        {
            try
            {
                User model = db.Users.Find(id);
                if (model != null)
                {
                    db.Users.Remove(model);
                    db.SaveChanges();
                }
                HttpResponseMessage res = new HttpResponseMessage(HttpStatusCode.OK);
                return res;
            }
            catch (Exception ex)
            {
                HttpResponseMessage res = new HttpResponseMessage(HttpStatusCode.InternalServerError);
                return res;
            }
        }
    }
}
